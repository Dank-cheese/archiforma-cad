/**
 * Small live 3D preview of a block (Block Editor / export dialog). Drag to orbit, wheel to zoom.
 */
import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import type { BlockDefinition } from '../types/model';
import { buildBlock3D, hashBlock } from './block3d';

interface Props {
  block: BlockDefinition;
  darkMode: boolean;
  className?: string;
  /** shape id to highlight (custom blocks) */
  highlightId?: string | null;
}

function disposeObject(obj: THREE.Object3D) {
  obj.traverse((o) => {
    const m = o as THREE.Mesh;
    if (m.isMesh) {
      m.geometry?.dispose();
      const mats = Array.isArray(m.material) ? m.material : [m.material];
      mats.forEach((mt) => mt?.dispose());
    }
  });
}

export default function BlockPreview3D({ block, darkMode, className, highlightId }: Props) {
  const hostRef = useRef<HTMLDivElement>(null);
  const stateRef = useRef<{
    renderer: THREE.WebGLRenderer;
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    model: THREE.Object3D | null;
    grid: THREE.GridHelper | null;
    target: THREE.Vector3;
    az: number;
    el: number;
    dist: number;
    render: () => void;
  } | null>(null);

  // one renderer for the component's lifetime
  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
    } catch {
      host.textContent = '3D preview unavailable (WebGL is off in this browser).';
      return;
    }
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    host.appendChild(renderer.domElement);
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.touchAction = 'none';
    const scene = new THREE.Scene();
    scene.add(new THREE.HemisphereLight(0xffffff, 0x8a8278, 1.6));
    const sun = new THREE.DirectionalLight(0xffffff, 1.6);
    sun.position.set(0.8, 1.6, 1.1);
    scene.add(sun);
    const camera = new THREE.PerspectiveCamera(32, 1, 0.5, 5000);
    const st = {
      renderer, scene, camera, model: null as THREE.Object3D | null, grid: null as THREE.GridHelper | null,
      target: new THREE.Vector3(), az: -0.65, el: 0.5, dist: 120,
      render: () => {
        const w = host.clientWidth || 300;
        const h = host.clientHeight || 220;
        if (renderer.domElement.width !== Math.round(w * renderer.getPixelRatio())) renderer.setSize(w, h, false);
        renderer.domElement.style.width = `${w}px`;
        renderer.domElement.style.height = `${h}px`;
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        const { az, el, dist, target } = st;
        camera.position.set(target.x + dist * Math.cos(el) * Math.sin(az), target.y + dist * Math.sin(el), target.z + dist * Math.cos(el) * Math.cos(az));
        camera.lookAt(target);
        renderer.render(scene, camera);
      },
    };
    stateRef.current = st;

    let drag: { x: number; y: number } | null = null;
    const el = renderer.domElement;
    const down = (e: PointerEvent) => {
      drag = { x: e.clientX, y: e.clientY };
      el.setPointerCapture(e.pointerId);
    };
    const move = (e: PointerEvent) => {
      if (!drag) return;
      st.az -= (e.clientX - drag.x) * 0.01;
      st.el = Math.max(-0.2, Math.min(1.45, st.el + (e.clientY - drag.y) * 0.01));
      drag = { x: e.clientX, y: e.clientY };
      st.render();
    };
    const up = () => (drag = null);
    const wheel = (e: WheelEvent) => {
      e.preventDefault();
      e.stopPropagation();
      st.dist = Math.max(10, Math.min(3000, st.dist * (e.deltaY > 0 ? 1.1 : 0.9)));
      st.render();
    };
    el.addEventListener('pointerdown', down);
    el.addEventListener('pointermove', move);
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
    el.addEventListener('wheel', wheel, { passive: false });
    const ro = new ResizeObserver(() => st.render());
    ro.observe(host);
    return () => {
      ro.disconnect();
      el.removeEventListener('pointerdown', down);
      el.removeEventListener('pointermove', move);
      el.removeEventListener('pointerup', up);
      el.removeEventListener('pointercancel', up);
      el.removeEventListener('wheel', wheel);
      if (st.model) disposeObject(st.model);
      renderer.dispose();
      host.removeChild(renderer.domElement);
      stateRef.current = null;
    };
  }, []);

  // rebuild the model when the block changes
  const sig = `${hashBlock(block)}|${block.mount ?? ''}|${highlightId ?? ''}`;
  const lastSize = useRef('');
  useEffect(() => {
    const st = stateRef.current;
    if (!st) return;
    if (st.model) {
      st.scene.remove(st.model);
      disposeObject(st.model);
    }
    if (st.grid) {
      st.scene.remove(st.grid);
      st.grid.geometry.dispose();
    }
    const hung = block.mount === 'ceiling';
    const { group } = buildBlock3D(block, block.width, block.depth, block.height, block.color, { ceiling: hung ? block.height + 12 : undefined });
    if (highlightId && block.kind === 'custom') {
      // tint the selected shape's mesh: rebuild that one shape alone and overlay it in amber
      const only = { ...block, entities: block.entities.filter((e) => e.id === highlightId) };
      if (only.entities.length) {
        const hl = buildBlock3D(only, block.width, block.depth, block.height, '#f59e0b', {}).group;
        hl.traverse((o) => {
          const m = o as THREE.Mesh;
          if (m.isMesh) m.material = new THREE.MeshBasicMaterial({ color: 0xf59e0b, transparent: true, opacity: 0.55, depthTest: false });
        });
        hl.renderOrder = 10;
        group.add(hl);
      }
    }
    st.scene.add(group);
    st.model = group;
    const box = new THREE.Box3().setFromObject(group);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    st.target.copy(center);
    const span = Math.max(size.x, size.y, size.z, 12);
    const sizeKey = `${Math.round(span)}`;
    if (lastSize.current !== sizeKey) {
      st.dist = span * 2.4;
      lastSize.current = sizeKey;
    }
    const gridSize = Math.ceil((Math.max(size.x, size.z) * 1.6) / 12) * 12 || 48;
    const grid = new THREE.GridHelper(gridSize, Math.max(2, gridSize / 6), darkMode ? 0x57534e : 0xa8a29e, darkMode ? 0x292524 : 0xe7e5e4);
    grid.position.y = hung ? box.min.y : 0;
    st.scene.add(grid);
    st.grid = grid;
    st.render();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sig, darkMode]);

  return (
    <div
      ref={hostRef}
      className={`relative overflow-hidden cursor-grab active:cursor-grabbing ${className ?? ''}`}
      title="Drag to orbit · scroll to zoom"
      data-testid="block-preview-3d"
    />
  );
}

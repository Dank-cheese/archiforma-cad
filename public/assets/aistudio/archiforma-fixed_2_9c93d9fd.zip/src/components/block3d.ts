/**
 * 3D MODEL OF A BLOCK (shared by the 3D view, the Block Editor preview and the 3D exporters).
 *
 * Local frame (three.js): x = block width (centred), y = up from the block's floor, z = plan +y.
 * The caller positions / rotates the returned group.
 *   - library components (libKind)  → parametric models in library3d.ts
 *   - starter kinds (bed, sofa, …)  → simple parametric furniture below
 *   - custom blocks                 → each 2D shape extruded with its own base / height / color
 */
import * as THREE from 'three';
import type { BlockDefinition, BlockPart3D, Point } from '../types/model';
import { buildLibrary3D } from './library3d';

export interface Block3DOptions {
  selected?: boolean;
  shadows?: boolean;
  chimneyTop?: number;
  ceiling?: number;
}

export function buildBlock3D(
  blockDef: BlockDefinition | undefined,
  w: number,
  d: number,
  h: number,
  color: string,
  opts: Block3DOptions = {},
): { group: THREE.Group; meshes: THREE.Mesh[] } {
  const o = { selected: !!opts.selected, shadows: !!opts.shadows, chimneyTop: opts.chimneyTop, ceiling: opts.ceiling };
  const isSelected = o.selected;
  const kind = blockDef?.kind ?? 'custom';
  const localMeshes: THREE.Mesh[] = [];
  const baseColor = new THREE.Color(
    isSelected ? '#f59e0b' : color || '#0d9488'
  );
  const primaryMat = new THREE.MeshStandardMaterial({
    name: 'body',
    color: baseColor,
    roughness: 0.55,
    metalness: 0.08,
  });
  const lightAccentMat = new THREE.MeshStandardMaterial({
    name: 'accent',
    color: isSelected ? 0xfde68a : 0xf5f5f4,
    roughness: 0.65,
    metalness: 0.05,
  });
  const darkAccentMat = new THREE.MeshStandardMaterial({
    name: 'metal',
    color: isSelected ? 0xb45309 : 0x334155,
    roughness: 0.4,
    metalness: 0.35,
  });
  const woodMat = new THREE.MeshStandardMaterial({
    name: 'wood',
    color: isSelected ? 0xd97706 : 0x78350f,
    roughness: 0.65,
    metalness: 0.05,
  });

  const compGroup = new THREE.Group();

  const addPart = (
    geo: THREE.BufferGeometry,
    mat: THREE.Material,
    px: number,
    py: number,
    pz: number
  ) => {
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(px, py, pz);
    mesh.castShadow = o.shadows;
    mesh.receiveShadow = true;
    compGroup.add(mesh);
    localMeshes.push(mesh);
    return mesh;
  };

  if (blockDef?.libKind) {
    const built = buildLibrary3D(blockDef.libKind, w, d, h, color || blockDef.color, { selected: isSelected, shadows: o.shadows, chimneyTop: o.chimneyTop, ceiling: o.ceiling });
    compGroup.add(built.group);
    localMeshes.push(...built.meshes);
  } else if (kind === 'bed') {
    addPart(
      new THREE.BoxGeometry(w, h * 0.32, d),
      woodMat,
      0,
      h * 0.16,
      0
    );
    addPart(
      new THREE.BoxGeometry(w, h, Math.max(3, d * 0.07)),
      woodMat,
      0,
      h * 0.5,
      -d * 0.465
    );
    addPart(
      new THREE.BoxGeometry(w * 0.94, h * 0.28, d * 0.88),
      lightAccentMat,
      0,
      h * 0.44,
      d * 0.03
    );
    addPart(
      new THREE.BoxGeometry(w * 0.95, h * 0.29, d * 0.56),
      primaryMat,
      0,
      h * 0.45,
      d * 0.19
    );
    addPart(
      new THREE.BoxGeometry(w * 0.36, h * 0.12, d * 0.18),
      lightAccentMat,
      -w * 0.22,
      h * 0.62,
      -d * 0.28
    );
    addPart(
      new THREE.BoxGeometry(w * 0.36, h * 0.12, d * 0.18),
      lightAccentMat,
      w * 0.22,
      h * 0.62,
      -d * 0.28
    );
  } else if (kind === 'sofa') {
    addPart(
      new THREE.BoxGeometry(w, h * 0.42, d),
      primaryMat,
      0,
      h * 0.21,
      0
    );
    addPart(
      new THREE.BoxGeometry(w, h * 0.58, d * 0.24),
      primaryMat,
      0,
      h * 0.71,
      -d * 0.38
    );
    addPart(
      new THREE.BoxGeometry(w * 0.11, h * 0.34, d),
      primaryMat,
      -w * 0.445,
      h * 0.59,
      0
    );
    addPart(
      new THREE.BoxGeometry(w * 0.11, h * 0.34, d),
      primaryMat,
      w * 0.445,
      h * 0.59,
      0
    );
  } else if (kind === 'table-chairs') {
    const tw = w * 0.68;
    const td = d * 0.58;
    addPart(
      new THREE.BoxGeometry(tw, h * 0.08, td),
      primaryMat,
      0,
      h * 0.96,
      0
    );
    const legW = Math.max(1.5, w * 0.03);
    for (const sx of [-1, 1]) {
      for (const sz of [-1, 1]) {
        addPart(
          new THREE.BoxGeometry(legW, h * 0.92, legW),
          woodMat,
          sx * (tw * 0.44),
          h * 0.46,
          sz * (td * 0.42)
        );
      }
    }
    const chairSeatH = h * 0.55;
    for (const sz of [-1, 1]) {
      addPart(
        new THREE.BoxGeometry(w * 0.22, h * 0.06, d * 0.16),
        woodMat,
        0,
        chairSeatH,
        sz * (d * 0.41)
      );
      addPart(
        new THREE.BoxGeometry(w * 0.22, h * 0.45, d * 0.04),
        woodMat,
        0,
        chairSeatH + h * 0.22,
        sz * (d * 0.48)
      );
    }
    for (const sx of [-1, 1]) {
      addPart(
        new THREE.BoxGeometry(w * 0.16, h * 0.06, d * 0.22),
        woodMat,
        sx * (w * 0.41),
        chairSeatH,
        0
      );
      addPart(
        new THREE.BoxGeometry(w * 0.04, h * 0.45, d * 0.22),
        woodMat,
        sx * (w * 0.48),
        chairSeatH + h * 0.22,
        0
      );
    }
  } else if (kind === 'toilet') {
    addPart(
      new THREE.BoxGeometry(w * 0.92, h * 0.58, d * 0.32),
      primaryMat,
      0,
      h * 0.71,
      -d * 0.34
    );
    addPart(
      new THREE.BoxGeometry(w * 0.65, h * 0.48, d * 0.75),
      primaryMat,
      0,
      h * 0.24,
      -d * 0.05
    );
    addPart(
      new THREE.CylinderGeometry(w * 0.42, w * 0.34, h * 0.52, 16),
      lightAccentMat,
      0,
      h * 0.26,
      d * 0.14
    );
  } else if (kind === 'sink') {
    addPart(
      new THREE.BoxGeometry(w, h * 0.88, d),
      primaryMat,
      0,
      h * 0.44,
      0
    );
    addPart(
      new THREE.BoxGeometry(w * 1.03, h * 0.12, d * 1.03),
      lightAccentMat,
      0,
      h * 0.94,
      0
    );
    addPart(
      new THREE.CylinderGeometry(
        Math.min(w, d) * 0.3,
        Math.min(w, d) * 0.25,
        2,
        16
      ),
      darkAccentMat,
      0,
      h + 0.5,
      d * 0.05
    );
    addPart(
      new THREE.BoxGeometry(1.5, 5, 4),
      darkAccentMat,
      0,
      h + 2.5,
      -d * 0.28
    );
  } else if (kind === 'bathtub') {
    addPart(
      new THREE.BoxGeometry(w, h, d),
      primaryMat,
      0,
      h * 0.5,
      0
    );
    addPart(
      new THREE.BoxGeometry(w * 0.86, h * 0.08, d * 0.78),
      lightAccentMat,
      0,
      h * 0.98,
      0
    );
    addPart(
      new THREE.BoxGeometry(3, 5, 3),
      darkAccentMat,
      -w * 0.42,
      h + 2.5,
      0
    );
  } else if (kind === 'kitchen-counter') {
    addPart(
      new THREE.BoxGeometry(w, h * 0.9, d),
      primaryMat,
      0,
      h * 0.45,
      0
    );
    addPart(
      new THREE.BoxGeometry(w * 1.02, h * 0.1, d * 1.04),
      lightAccentMat,
      0,
      h * 0.95,
      0
    );
    addPart(
      new THREE.BoxGeometry(w * 0.24, 1.5, d * 0.58),
      darkAccentMat,
      -w * 0.14,
      h + 0.4,
      0.04 * d
    );
    addPart(
      new THREE.BoxGeometry(w * 0.24, 1.5, d * 0.58),
      darkAccentMat,
      w * 0.14,
      h + 0.4,
      0.04 * d
    );
  } else if (kind === 'fridge') {
    addPart(
      new THREE.BoxGeometry(w, h, d * 0.92),
      primaryMat,
      0,
      h * 0.5,
      -d * 0.04
    );
    addPart(
      new THREE.BoxGeometry(w * 0.48, h * 0.96, d * 0.08),
      lightAccentMat,
      -w * 0.25,
      h * 0.5,
      d * 0.46
    );
    addPart(
      new THREE.BoxGeometry(w * 0.48, h * 0.96, d * 0.08),
      lightAccentMat,
      w * 0.25,
      h * 0.5,
      d * 0.46
    );
  } else if (kind === 'stove') {
    addPart(
      new THREE.BoxGeometry(w, h * 0.92, d),
      primaryMat,
      0,
      h * 0.46,
      0
    );
    addPart(
      new THREE.BoxGeometry(w, h * 0.18, d * 0.14),
      darkAccentMat,
      0,
      h * 1.01,
      -d * 0.43
    );
    const br = Math.min(w, d) * 0.13;
    for (const sx of [-1, 1]) {
      for (const sz of [-1, 1]) {
        addPart(
          new THREE.CylinderGeometry(br, br, 1.2, 16),
          darkAccentMat,
          sx * (w * 0.26),
          h * 0.93,
          sz * (d * 0.22)
        );
      }
    }
  } else if (kind === 'stairs') {
    const steps = 10;
    const treadD = d / steps;
    const stepH = h / steps;
    for (let s = 0; s < steps; s++) {
      const curH = stepH * (s + 1);
      const zCenter = d / 2 - treadD * (s + 0.5);
      addPart(
        new THREE.BoxGeometry(w * 0.92, curH, treadD * 0.98),
        primaryMat,
        0,
        curH / 2,
        zCenter
      );
    }
    addPart(
      new THREE.BoxGeometry(w * 0.04, h, d),
      woodMat,
      -w * 0.48,
      h * 0.5,
      0
    );
    addPart(
      new THREE.BoxGeometry(w * 0.04, h, d),
      woodMat,
      w * 0.48,
      h * 0.5,
      0
    );
  } else if (kind === 'tree') {
    const trunkR = Math.max(3, Math.min(w, d) * 0.08);
    const canopyR = Math.min(w, d) * 0.42;
    addPart(
      new THREE.CylinderGeometry(trunkR * 0.75, trunkR, h * 0.45, 12),
      woodMat,
      0,
      h * 0.225,
      0
    );
    addPart(
      new THREE.SphereGeometry(canopyR, 16, 14),
      primaryMat,
      0,
      h * 0.68,
      0
    );
    addPart(
      new THREE.SphereGeometry(canopyR * 0.72, 14, 12),
      primaryMat,
      -canopyR * 0.45,
      h * 0.58,
      canopyR * 0.25
    );
    addPart(
      new THREE.SphereGeometry(canopyR * 0.72, 14, 12),
      primaryMat,
      canopyR * 0.45,
      h * 0.6,
      -canopyR * 0.25
    );
  } else {
    buildCustomParts(blockDef, w, d, h, color, isSelected, addPart, primaryMat);
  }
  return { group: compGroup, meshes: localMeshes };
}

/** Short fingerprint of everything that affects a block's 3D model (for render caches). */
export function hashBlock(def: BlockDefinition): string {
  const str = JSON.stringify([def.kind, def.libKind, def.width, def.depth, def.height, def.color, def.entities, def.parts3d ?? null]);
  let h1 = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h1 ^= str.charCodeAt(i);
    h1 = Math.imul(h1, 0x01000193);
  }
  return `${str.length.toString(36)}${(h1 >>> 0).toString(36)}`;
}

/** Effective 3D settings of one shape of a custom block (at the block's own size). */
export function partSettings(def: BlockDefinition, shapeId: string): Required<Omit<BlockPart3D, 'color'>> & { color: string } {
  const p = def.parts3d?.[shapeId] ?? {};
  const z = Math.max(0, Math.min(def.height - 0.25, p.z ?? 0));
  const height = Math.max(0.25, Math.min(def.height - z, p.height ?? def.height - z));
  return { z, height, color: p.color || def.color, hidden: !!p.hidden };
}

const NAMED_COLORS: Record<string, string> = {
  '#8a5a33': 'oak', '#5b3a22': 'walnut', '#1f1f1f': 'black', '#f8fafc': 'white', '#78716c': 'stone', '#334155': 'slate',
  '#0d9488': 'teal', '#b45309': 'amber', '#6366f1': 'indigo', '#0284c7': 'blue', '#15803d': 'green', '#dc2626': 'red',
};
/** Friendly material name for a part color (becomes the layer / material name in exports). */
export function colorName(hex: string): string {
  const h = hex.toLowerCase();
  return NAMED_COLORS[h] ?? `color-${h.replace('#', '')}`;
}

type AddPart = (geo: THREE.BufferGeometry, mat: THREE.Material, px: number, py: number, pz: number) => THREE.Mesh;

/** Custom blocks: extrude rectangles, circles and closed polylines with their own base / height / color. */
function buildCustomParts(def: BlockDefinition | undefined, w: number, d: number, h: number, color: string, selected: boolean, addPart: AddPart, primaryMat: THREE.Material) {
  let added = 0;
  if (def && def.entities.length > 0) {
    const sx = w / Math.max(1, def.width);
    const sy = d / Math.max(1, def.depth);
    const sz = h / Math.max(1, def.height);
    const mats = new Map<string, THREE.Material>();
    const matFor = (hex: string) => {
      if (selected || hex.toLowerCase() === (color || def.color).toLowerCase()) return primaryMat;
      let m = mats.get(hex);
      if (!m) {
        m = new THREE.MeshStandardMaterial({ name: colorName(hex), color: new THREE.Color(hex), roughness: 0.55, metalness: 0.08 });
        mats.set(hex, m);
      }
      return m;
    };
    for (const ent of def.entities) {
      if (ent.type !== 'rectangle' && ent.type !== 'circle' && !(ent.type === 'polyline' && ent.closed && ent.points.length >= 3)) continue;
      const ps = partSettings(def, ent.id);
      if (ps.hidden) continue;
      const z0 = ps.z * sz;
      const hh = ps.height * sz;
      // a part colored like the block follows the instance color; others keep their own color
      const hex = !def.parts3d?.[ent.id]?.color ? color || def.color : ps.color;
      const mat = matFor(hex);
      if (ent.type === 'rectangle') {
        const rw = Math.abs(ent.p2.x - ent.p1.x) * sx;
        const rd = Math.abs(ent.p2.y - ent.p1.y) * sy;
        if (rw < 0.25 || rd < 0.25) continue;
        addPart(new THREE.BoxGeometry(rw, hh, rd), mat, ((ent.p1.x + ent.p2.x) / 2) * sx, z0 + hh / 2, ((ent.p1.y + ent.p2.y) / 2) * sy);
        added++;
      } else if (ent.type === 'circle') {
        const rx = ent.radius * sx;
        const rz = ent.radius * sy;
        if (rx < 0.25 || rz < 0.25) continue;
        const mesh = addPart(new THREE.CylinderGeometry(1, 1, hh, 24), mat, ent.center.x * sx, z0 + hh / 2, ent.center.y * sy);
        mesh.scale.set(rx, 1, rz);
        added++;
      } else if (ent.type === 'polyline') {
        const pts: Point[] = ent.points.map((q) => ({ x: q.x * sx, y: q.y * sy }));
        const shape = new THREE.Shape(pts.map((q) => new THREE.Vector2(q.x, -q.y)));
        const geo = new THREE.ExtrudeGeometry(shape, { depth: hh, bevelEnabled: false });
        // shape lies in XY (y = −plan y); rotate so the extrusion goes up (+Y) and plan y maps to +Z
        geo.rotateX(-Math.PI / 2);
        addPart(geo, mat, 0, z0, 0);
        added++;
      }
    }
  }
  if (!added) addPart(new THREE.BoxGeometry(w, h, d), primaryMat, 0, h / 2, 0);
}

// ---------------------------------------------------------------------------------------------
// Export: block → triangle lists per material in CAD axes (X right, Y back, Z up), inches
// ---------------------------------------------------------------------------------------------

export interface BlockMeshPart {
  name: string;
  color: string;
  opacity: number;
  positions: number[];
}

/**
 * Builds the block at its own size and flattens it into per-material triangle lists.
 * Floor items sit on Z = 0; ceiling items hang below Z = 0 (their mounting point).
 */
export function blockMeshParts(def: BlockDefinition): BlockMeshPart[] {
  const hung = def.mount === 'ceiling';
  const ceiling = hung ? def.height + 12 : undefined;
  const { group } = buildBlock3D(def, def.width, def.depth, def.height, def.color, { ceiling });
  group.updateMatrixWorld(true);
  const zShift = hung ? -(ceiling as number) : 0;
  const parts = new Map<string, BlockMeshPart>();
  const v = new THREE.Vector3();
  group.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (!mesh.isMesh || !mesh.visible) return;
    const geo = mesh.geometry as THREE.BufferGeometry;
    const pos = geo.getAttribute('position') as THREE.BufferAttribute | undefined;
    if (!pos) return;
    const index = geo.getIndex();
    const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    const groups = geo.groups.length ? geo.groups : [{ start: 0, count: index ? index.count : pos.count, materialIndex: 0 }];
    for (const g of groups) {
      const mat = (mats[g.materialIndex ?? 0] ?? mats[0]) as THREE.MeshStandardMaterial;
      const color = `#${(mat.color ?? new THREE.Color('#808080')).getHexString()}`;
      const opacity = mat.transparent ? Math.max(0.05, mat.opacity ?? 1) : 1;
      const name = (mat.name || 'body').toLowerCase();
      const key = `${name}|${color}|${opacity.toFixed(2)}`;
      let part = parts.get(key);
      if (!part) {
        part = { name, color, opacity, positions: [] };
        parts.set(key, part);
      }
      const end = Math.min(g.start + g.count, index ? index.count : pos.count);
      for (let i = g.start; i + 2 < end; i += 3) {
        for (let k = 0; k < 3; k++) {
          const vi = index ? index.getX(i + k) : i + k;
          v.fromBufferAttribute(pos, vi).applyMatrix4(mesh.matrixWorld);
          // three (x, y up, z = plan +y / front) → CAD (X, Y = back, Z up)
          part.positions.push(v.x, -v.z, v.y + zShift);
        }
      }
    }
  });
  // name collisions (two different colors called "body") get a suffix so layers stay distinct
  const out = [...parts.values()];
  const seen = new Map<string, number>();
  for (const p of out) {
    const n = seen.get(p.name) ?? 0;
    seen.set(p.name, n + 1);
    if (n > 0) p.name = `${p.name}-${n + 1}`;
  }
  return out;
}

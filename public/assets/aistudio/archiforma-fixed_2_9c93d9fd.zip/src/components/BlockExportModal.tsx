/**
 * DOWNLOAD 3D BLOCK — export one block for AutoCAD, Revit and other 3D programs.
 */
import { useMemo, useState, type ReactNode } from 'react';
import { Box, Download, FileArchive, FileCode2, Layers3, Printer, X } from 'lucide-react';
import type { ArchEntity, BlockDefinition, UnitSystem } from '../types/model';
import { createBlankProject, formatLength } from '../engine/geometry';
import { exportModelToDXF } from '../engine/dxfExport';
import {
  blockFileBase,
  exportReadme,
  makeZip,
  triangleCount,
  writeBlockDxf,
  writeBlockIfc,
  writeBlockObj,
  writeBlockStl,
  type BlockExportMeta,
  type ExportUnits,
} from '../engine/blockExport';
import { blockMeshParts } from './block3d';
import BlockPreview3D from './BlockPreview3D';

interface Props {
  block: BlockDefinition | null;
  units: UnitSystem;
  darkMode: boolean;
  onClose: () => void;
  onExported?: (message: string) => void;
}

function save(data: string | Uint8Array, fileName: string, mime: string) {
  const part: BlobPart = typeof data === 'string' ? data : (data.slice().buffer as ArrayBuffer);
  const blob = new Blob([part], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

/** The block's 2D plan symbol as its own DXF (for Revit plan views / AutoCAD 2D blocks). */
function symbolDxf(block: BlockDefinition, units: ExportUnits): string {
  const m = createBlankProject();
  const entities = block.entities.map((e) => ({ ...e, layer: 'A-FURN', levelId: 'level-1' }) as ArchEntity);
  return exportModelToDXF({ ...m, projectName: block.name, entities, layers: m.layers.filter((l) => l.id === '0' || l.id === 'A-FURN'), settings: { ...m.settings, units: units === 'mm' ? 'metric' : 'imperial' } }, { levelId: 'level-1' });
}

type Tab = 'autocad' | 'revit' | 'other';

export default function BlockExportModal({ block, units, darkMode, onClose, onExported }: Props) {
  const [fileUnits, setFileUnits] = useState<ExportUnits>(units === 'metric' ? 'mm' : 'in');
  const [tab, setTab] = useState<Tab>('revit');
  const [busy, setBusy] = useState<string | null>(null);

  const parts = useMemo(() => (block ? blockMeshParts(block) : []), [block]);
  if (!block) return null;

  const meta: BlockExportMeta = { name: block.name, description: block.description, category: block.category, width: block.width, depth: block.depth, height: block.height };
  const base = blockFileBase(block.name);
  const tris = triangleCount(parts);
  const unitWord = fileUnits === 'mm' ? 'millimeters' : 'inches';

  const run = (label: string, fn: () => void) => {
    setBusy(label);
    // let the button show its busy state before the (synchronous) export work
    setTimeout(() => {
      try {
        fn();
        onExported?.(`Downloaded "${block.name}" as ${label}.`);
      } finally {
        setBusy(null);
      }
    }, 20);
  };

  const formats: Array<{ id: string; label: string; ext: string; apps: string; desc: string; icon: typeof Box; go: () => void }> = [
    {
      id: 'dxf', label: '3D DXF', ext: '.dxf', apps: 'AutoCAD · Revit', icon: Layers3,
      desc: `A named AutoCAD block of 3D meshes, one layer per material, in ${unitWord}. Best choice for AutoCAD and for making a Revit family.`,
      go: () => save(writeBlockDxf(meta, parts, fileUnits), `${base}.dxf`, 'application/dxf'),
    },
    {
      id: 'ifc', label: 'IFC4', ext: '.ifc', apps: 'Revit · ArchiCAD · BIM', icon: Box,
      desc: 'A BIM furniture type with colors and Width / Depth / Height properties (always millimeters).',
      go: () => save(writeBlockIfc(meta, parts), `${base}.ifc`, 'application/x-step'),
    },
    {
      id: 'obj', label: 'OBJ + MTL', ext: '.zip', apps: 'Revit 2023+ · SketchUp · Blender', icon: FileCode2,
      desc: 'Mesh with materials (Y-up, the OBJ standard). Downloads as a .zip so the .obj and its .mtl colors stay together.',
      go: () => {
        const { obj, mtl, mtlName } = writeBlockObj(meta, parts, fileUnits);
        save(makeZip([{ name: `${base}.obj`, data: obj }, { name: mtlName, data: mtl }]), `${base}_obj.zip`, 'application/zip');
      },
    },
    {
      id: 'stl', label: 'STL', ext: '.stl', apps: 'Revit · 3D printing', icon: Printer,
      desc: `Single mesh without colors, Z-up, in ${unitWord}.`,
      go: () => save(writeBlockStl(meta, parts, fileUnits), `${base}.stl`, 'model/stl'),
    },
    {
      id: 'dxf2d', label: '2D plan symbol', ext: '.dxf', apps: 'AutoCAD · Revit plan views', icon: Layers3,
      desc: 'The flat plan symbol you see in ARCHIFORMA, for 2D drawings or a Revit family\'s plan view.',
      go: () => save(symbolDxf(block, fileUnits), `${base}_2D.dxf`, 'application/dxf'),
    },
  ];

  const downloadAll = () =>
    run('a ZIP with every format', () => {
      const { obj, mtl, mtlName } = writeBlockObj(meta, parts, fileUnits);
      const zip = makeZip([
        { name: `${base}.dxf`, data: writeBlockDxf(meta, parts, fileUnits) },
        { name: `${base}_2D.dxf`, data: symbolDxf(block, fileUnits) },
        { name: `${base}.ifc`, data: writeBlockIfc(meta, parts) },
        { name: `${base}.obj`, data: obj },
        { name: mtlName, data: mtl },
        { name: `${base}.stl`, data: writeBlockStl(meta, parts, fileUnits) },
        { name: 'HOW-TO-USE.txt', data: exportReadme(meta, fileUnits) },
      ]);
      save(zip, `${base}_3D_block.zip`, 'application/zip');
    });

  const panel = darkMode ? 'bg-stone-900 border-stone-700 text-stone-100' : 'bg-white border-stone-200 text-stone-900';
  const soft = darkMode ? 'bg-stone-950/60 border-stone-800' : 'bg-stone-50 border-stone-200';
  const muted = darkMode ? 'text-stone-400' : 'text-stone-500';
  const revitUnits = fileUnits === 'mm' ? 'Millimeter' : 'Inch';

  const steps: Record<Tab, ReactNode[]> = {
    autocad: [
      <>Download the <b>3D DXF</b>.</>,
      <>In AutoCAD type <code>INSERT</code> ▸ <b>Browse</b> and pick <code>{base}.dxf</code> (or drag the file into your drawing). It comes in as one block named “{block.name}”, sized in {unitWord}.</>,
      <>Switch to a 3D view (<code>VIEW</code> ▸ SE Isometric, visual style Realistic) to see it. Materials are on their own layers.</>,
      <>Need solids? Explode the block, then <code>MESHSMOOTH</code> and <code>CONVTOSOLID</code>.</>,
    ],
    revit: [
      <>Download the <b>3D DXF</b> (and the <b>2D plan symbol</b> if you want a clean plan view).</>,
      <>In Revit: <b>File ▸ New ▸ Family</b> ▸ <code>Furniture.rft</code> (or <code>Generic Model.rft</code>).</>,
      <><b>Insert ▸ Import CAD</b> ▸ <code>{base}.dxf</code>. Set <b>Import units: {revitUnits}</b> and <b>Positioning: Auto – Origin to Origin</b>.</>,
      <>Optional: open the <b>Ref. Level</b> floor plan, import <code>{base}_2D.dxf</code>, and set the 3D import to show in 3D views only.</>,
      <>Save the family ▸ <b>Load into Project</b> and place it like any component. Or skip the family: <b>File ▸ Open ▸ IFC</b> opens the IFC as a ready-made furniture element.</>,
    ],
    other: [
      <><b>SketchUp, Blender, 3ds Max, Rhino, Twinmotion, Enscape:</b> import the OBJ (unzip first, keep the .mtl beside the .obj for colors).</>,
      <>If the model comes in lying on its side, rotate it 90° about X. OBJ files are Y-up by convention; some CAD tools expect Z-up.</>,
      <><b>3D printing:</b> use the STL. It is in {unitWord}; scale it in your slicer.</>,
      <><b>ArchiCAD, Vectorworks, BIM viewers:</b> use the IFC.</>,
    ],
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs" role="dialog" aria-modal="true" aria-labelledby="bexp-title">
      <div className={`w-full max-w-4xl rounded-xl border shadow-2xl overflow-hidden flex flex-col max-h-[92vh] ${panel}`}>
        <div className={`px-5 py-3.5 border-b flex items-center justify-between ${darkMode ? 'border-stone-800' : 'border-stone-200'}`}>
          <div className="flex items-center gap-2.5 min-w-0">
            <Download className="w-5 h-5 text-amber-600 shrink-0" />
            <div className="min-w-0">
              <h2 id="bexp-title" className="text-sm font-bold truncate">Download 3D block: {block.name}</h2>
              <p className={`text-[11px] ${muted}`}>For AutoCAD, Revit and other 3D programs.</p>
            </div>
          </div>
          <button type="button" onClick={onClose} className={`p-1.5 rounded-lg ${muted} hover:bg-stone-500/10`} aria-label="Close download dialog">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="overflow-y-auto p-5 grid grid-cols-1 md:grid-cols-[minmax(0,5fr)_minmax(0,7fr)] gap-5">
          {/* preview + facts */}
          <div className="flex flex-col gap-3">
            <BlockPreview3D block={block} darkMode={darkMode} className={`h-56 md:h-64 rounded-lg border ${soft}`} />
            <dl className={`grid grid-cols-2 gap-x-3 gap-y-1 text-xs rounded-lg border p-3 ${soft}`}>
              <dt className={muted}>Size</dt>
              <dd className="font-mono">{formatLength(block.width, units)} × {formatLength(block.depth, units)} × {formatLength(block.height, units)}</dd>
              <dt className={muted}>Materials</dt>
              <dd>{parts.length} ({parts.map((p) => p.name).join(', ')})</dd>
              <dt className={muted}>Triangles</dt>
              <dd className="font-mono">{tris.toLocaleString()}</dd>
              <dt className={muted}>Insertion point</dt>
              <dd>Base point on the floor{block.mount === 'ceiling' ? ' (hangs below: ceiling mount)' : ''}</dd>
            </dl>
            <div className={`text-xs rounded-lg border p-3 ${soft}`}>
              <div className="font-semibold mb-1.5">File units</div>
              <div className="flex gap-1" role="radiogroup" aria-label="File units">
                {(['in', 'mm'] as ExportUnits[]).map((u) => (
                  <button
                    key={u}
                    type="button"
                    role="radio"
                    aria-checked={fileUnits === u}
                    onClick={() => setFileUnits(u)}
                    className={`flex-1 px-2 py-1 rounded-md border text-xs font-medium ${fileUnits === u ? 'bg-amber-600 border-amber-600 text-white' : darkMode ? 'border-stone-700' : 'border-stone-300'}`}
                  >
                    {u === 'in' ? 'Inches' : 'Millimeters'}
                  </button>
                ))}
              </div>
              <p className={`mt-1.5 ${muted}`}>Used for DXF, OBJ and STL. IFC is always millimeters.</p>
            </div>
          </div>

          {/* formats */}
          <div className="flex flex-col gap-2.5">
            <button
              type="button"
              onClick={downloadAll}
              disabled={!!busy}
              className="flex items-center gap-3 rounded-lg bg-amber-600 hover:bg-amber-700 disabled:opacity-60 text-white px-4 py-3 text-left"
            >
              <FileArchive className="w-6 h-6 shrink-0" />
              <span className="flex-1 min-w-0">
                <span className="block text-sm font-semibold">Download everything (.zip)</span>
                <span className="block text-[11px] opacity-90">3D DXF, 2D DXF, IFC, OBJ, STL and a how-to guide</span>
              </span>
              <Download className="w-4 h-4" />
            </button>
            {formats.map((f) => (
              <div key={f.id} className={`flex items-start gap-3 rounded-lg border p-3 ${soft}`}>
                <f.icon className="w-5 h-5 mt-0.5 text-amber-600 shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-baseline gap-x-2">
                    <span className="text-sm font-semibold">{f.label}</span>
                    <span className={`text-[11px] font-mono ${muted}`}>{f.ext}</span>
                    <span className="text-[11px] font-medium text-amber-700 dark:text-amber-400">{f.apps}</span>
                  </div>
                  <p className={`text-[11px] mt-0.5 ${muted}`}>{f.desc}</p>
                </div>
                <button
                  type="button"
                  onClick={() => run(f.label, f.go)}
                  disabled={!!busy}
                  aria-label={`Download ${f.label}`}
                  className={`shrink-0 flex items-center gap-1 px-2.5 py-1.5 rounded-md border text-xs font-medium hover:border-amber-500 hover:text-amber-700 disabled:opacity-50 ${darkMode ? 'border-stone-700 bg-stone-900' : 'border-stone-300 bg-white'}`}
                >
                  <Download className="w-3.5 h-3.5" /> {busy === f.label ? 'Working…' : 'Download'}
                </button>
              </div>
            ))}
          </div>

          {/* how to */}
          <div className={`md:col-span-2 rounded-lg border ${soft}`}>
            <div className={`flex gap-1 p-1.5 border-b ${darkMode ? 'border-stone-800' : 'border-stone-200'}`} role="tablist" aria-label="How to use the file">
              {(
                [
                  ['revit', 'Use in Revit'],
                  ['autocad', 'Use in AutoCAD'],
                  ['other', 'Other apps'],
                ] as Array<[Tab, string]>
              ).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  role="tab"
                  aria-selected={tab === id}
                  onClick={() => setTab(id)}
                  className={`px-3 py-1 rounded-md text-xs font-semibold ${tab === id ? 'bg-amber-600 text-white' : `${muted} hover:bg-stone-500/10`}`}
                >
                  {label}
                </button>
              ))}
            </div>
            <ol className="list-decimal pl-8 pr-4 py-3 space-y-1.5 text-xs leading-relaxed [&_code]:font-mono [&_code]:text-[11px] [&_code]:px-1 [&_code]:rounded [&_code]:bg-stone-500/10">
              {steps[tab].map((s, i) => (
                <li key={i}>{s}</li>
              ))}
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
}

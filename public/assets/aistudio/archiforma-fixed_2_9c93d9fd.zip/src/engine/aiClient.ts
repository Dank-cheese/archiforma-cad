/**
 * Gemini connection for "Design with AI".
 *
 * API key, in order:
 *   1. a key the user pasted into the AI settings (kept only in this browser's localStorage)
 *   2. GEMINI_API_KEY provided by Google AI Studio (injected at build time by vite.config.ts)
 * Public builds (GitHub Pages, docs/index.html) never contain a key: each visitor uses their own.
 */
import { AI_PLAN_SCHEMA, AI_PLAN_SYSTEM_PROMPT, buildAiUserPrompt, parseAiPlan, type AiPlan } from './aiPlan';

const KEY_STORAGE = 'archiforma_gemini_key_v1';
const MODEL_STORAGE = 'archiforma_gemini_model_v1';

export const AI_MODELS: Array<{ id: string; label: string }> = [
  { id: 'gemini-flash-latest', label: 'Gemini Flash (fast)' },
  { id: 'gemini-pro-latest', label: 'Gemini Pro (most accurate, slower)' },
];
const FALLBACK_MODEL = 'gemini-2.5-flash';

function envKey(): string {
  let k = '';
  try {
    // Vite `define` replaces this exact expression with a string at build time.
    // Without it (plain browser), `process` is undefined and the catch below applies.
    k = process.env.GEMINI_API_KEY || '';
  } catch {
    k = '';
  }
  return k && !/^MY_/i.test(k) ? k : '';
}

export function getStoredKey(): string {
  try {
    return localStorage.getItem(KEY_STORAGE) || '';
  } catch {
    return '';
  }
}
export function setStoredKey(key: string) {
  try {
    if (key.trim()) localStorage.setItem(KEY_STORAGE, key.trim());
    else localStorage.removeItem(KEY_STORAGE);
  } catch {
    /* storage unavailable */
  }
}
export function hasBuiltInKey(): boolean {
  return !!envKey();
}
export function resolveApiKey(): string {
  return getStoredKey() || envKey();
}
export function getStoredModel(): string {
  try {
    return localStorage.getItem(MODEL_STORAGE) || AI_MODELS[0].id;
  } catch {
    return AI_MODELS[0].id;
  }
}
export function setStoredModel(model: string) {
  try {
    localStorage.setItem(MODEL_STORAGE, model);
  } catch {
    /* storage unavailable */
  }
}

export interface SketchInput {
  mimeType: string;
  base64: string; // no data: prefix
}

export class AiDesignError extends Error {
  constructor(message: string, readonly needsKey = false) {
    super(message);
  }
}

function friendly(err: unknown): AiDesignError {
  const raw = err instanceof Error ? err.message : String(err);
  const msg = raw.toLowerCase();
  if (/api[_ ]?key|permission_denied|unauthenticated|401|403/.test(msg) && /invalid|not valid|denied|unauth|401|403|missing/.test(msg)) {
    return new AiDesignError('Gemini rejected the API key. Check it in AI settings.', true);
  }
  if (/429|quota|rate|resource_exhausted/.test(msg)) return new AiDesignError('Gemini is busy or your free quota is used up. Wait a minute and try again.');
  if (/safety|blocked/.test(msg)) return new AiDesignError('Gemini declined this image. Try a different sketch.');
  if (/failed to fetch|network|load failed/.test(msg)) return new AiDesignError("Couldn't reach Gemini. Check your internet connection.");
  if (/abort/.test(msg)) return new AiDesignError('Cancelled.');
  return new AiDesignError(raw.length > 220 ? `${raw.slice(0, 220)}…` : raw || 'Something went wrong talking to Gemini.');
}

/** Sends the brief (and sketch, if any) to Gemini and returns the parsed plan. */
export async function requestAiPlan(args: {
  prompt: string;
  sketch: SketchInput | null;
  units: 'imperial' | 'metric';
  model?: string;
  signal?: AbortSignal;
}): Promise<AiPlan> {
  const apiKey = resolveApiKey();
  if (!apiKey) throw new AiDesignError('Add a Gemini API key to use AI design.', true);
  const { GoogleGenAI } = await import('@google/genai');
  const ai = new GoogleGenAI({ apiKey });
  const parts: Array<Record<string, unknown>> = [];
  if (args.sketch) parts.push({ inlineData: { mimeType: args.sketch.mimeType, data: args.sketch.base64 } });
  parts.push({ text: buildAiUserPrompt(args.prompt, !!args.sketch, args.units) });

  const run = (model: string) =>
    ai.models.generateContent({
      model,
      contents: [{ role: 'user', parts }],
      config: {
        systemInstruction: AI_PLAN_SYSTEM_PROMPT,
        responseMimeType: 'application/json',
        responseJsonSchema: AI_PLAN_SCHEMA,
        temperature: 0.2,
        abortSignal: args.signal,
      },
    });

  const model = args.model || getStoredModel();
  let res;
  try {
    res = await run(model);
  } catch (err) {
    const m = err instanceof Error ? err.message : String(err);
    if (/404|not found|not_found|is not supported/i.test(m) && model !== FALLBACK_MODEL) {
      try {
        res = await run(FALLBACK_MODEL);
      } catch (err2) {
        throw friendly(err2);
      }
    } else {
      throw friendly(err);
    }
  }
  const text = res.text ?? '';
  if (!text.trim()) throw new AiDesignError('Gemini returned an empty answer. Try again or add more detail.');
  return parseAiPlan(text);
}

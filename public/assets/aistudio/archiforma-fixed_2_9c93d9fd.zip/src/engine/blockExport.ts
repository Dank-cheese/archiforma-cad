/**
 * BLOCK 3D EXPORT — write one block's 3D model to files other programs open.
 *
 *   DXF (R2000, AC1015)  AutoCAD (INSERT / open) · Revit (Insert ▸ Import CAD, incl. Family Editor)
 *   OBJ + MTL            Revit 2023+, SketchUp, 3ds Max, Blender, Rhino, Twinmotion, Enscape
 *   STL (binary)         Revit, 3D printing, most mesh tools
 *   IFC4                 Revit (Open / Link IFC), ArchiCAD, Vectorworks, BIM viewers
 *   ZIP                  all of the above + a how-to text
 *
 * Input is a list of MeshParts: triangles in CAD axes (X = width / right, Y = back, Z = up) in
 * inches, one part per material. Pure: no DOM, no three.js (see components/block3d.ts for that).
 */
import { hexToNearestAci, sanitizeDxfName } from './dxfExport';
import { ifcReal, ifcStr, makeIfcGuid } from './ifcExport';

export interface MeshPart {
  /** material name ("wood", "body", "glass", …) */
  name: string;
  /** #rrggbb */
  color: string;
  /** 1 = opaque */
  opacity: number;
  /** flat triangle list: x0,y0,z0, x1,y1,z1, x2,y2,z2, … (inches, Z up) */
  positions: number[];
}

export type ExportUnits = 'in' | 'mm';
const UNIT_SCALE: Record<ExportUnits, number> = { in: 1, mm: 25.4 };

export interface BlockExportMeta {
  name: string;
  description?: string;
  category?: string;
  width: number;  // inches
  depth: number;
  height: number;
}

// ---------------------------------------------------------------------------------------------
// Mesh helpers
// ---------------------------------------------------------------------------------------------

interface IndexedMesh {
  verts: number[]; // x,y,z…
  tris: number[];  // 0-based vertex indices, 3 per triangle
}

/** Merges identical vertices (to 1e-4") and drops degenerate triangles. */
export function indexMesh(positions: number[], scale = 1): IndexedMesh {
  const map = new Map<string, number>();
  const verts: number[] = [];
  const tris: number[] = [];
  const idx = (i: number) => {
    const x = positions[i] * scale;
    const y = positions[i + 1] * scale;
    const z = positions[i + 2] * scale;
    const k = `${Math.round(x * 1e4)},${Math.round(y * 1e4)},${Math.round(z * 1e4)}`;
    let v = map.get(k);
    if (v === undefined) {
      v = verts.length / 3;
      verts.push(x, y, z);
      map.set(k, v);
    }
    return v;
  };
  for (let i = 0; i + 8 < positions.length; i += 9) {
    const a = idx(i);
    const b = idx(i + 3);
    const c = idx(i + 6);
    if (a === b || b === c || a === c) continue;
    tris.push(a, b, c);
  }
  return { verts, tris };
}

function triNormal(m: IndexedMesh, t: number): [number, number, number] {
  const [a, b, c] = [m.tris[t * 3], m.tris[t * 3 + 1], m.tris[t * 3 + 2]];
  const ax = m.verts[a * 3], ay = m.verts[a * 3 + 1], az = m.verts[a * 3 + 2];
  const ux = m.verts[b * 3] - ax, uy = m.verts[b * 3 + 1] - ay, uz = m.verts[b * 3 + 2] - az;
  const vx = m.verts[c * 3] - ax, vy = m.verts[c * 3 + 1] - ay, vz = m.verts[c * 3 + 2] - az;
  const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
  const L = Math.hypot(nx, ny, nz) || 1;
  return [nx / L, ny / L, nz / L];
}

/**
 * For each triangle edge: true when it should be drawn. Edges shared with a neighbour that is
 * coplanar or nearly so (smooth curved surface) are hidden so boxes read as clean quads and
 * cylinders without facet lines.
 */
export function visibleEdges(m: IndexedMesh, smoothDeg = 25): boolean[] {
  const nT = m.tris.length / 3;
  const normals = Array.from({ length: nT }, (_, t) => triNormal(m, t));
  const edgeTris = new Map<string, number[]>();
  const key = (a: number, b: number) => (a < b ? `${a}_${b}` : `${b}_${a}`);
  for (let t = 0; t < nT; t++) {
    for (let e = 0; e < 3; e++) {
      const k = key(m.tris[t * 3 + e], m.tris[t * 3 + ((e + 1) % 3)]);
      const arr = edgeTris.get(k);
      if (arr) arr.push(t);
      else edgeTris.set(k, [t]);
    }
  }
  const cosLim = Math.cos((smoothDeg * Math.PI) / 180);
  const out: boolean[] = new Array(nT * 3).fill(true);
  for (let t = 0; t < nT; t++) {
    for (let e = 0; e < 3; e++) {
      const k = key(m.tris[t * 3 + e], m.tris[t * 3 + ((e + 1) % 3)]);
      const arr = edgeTris.get(k)!;
      if (arr.length !== 2) continue;
      const o = arr[0] === t ? arr[1] : arr[0];
      const n1 = normals[t];
      const n2 = normals[o];
      if (n1[0] * n2[0] + n1[1] * n2[1] + n1[2] * n2[2] >= cosLim) out[t * 3 + e] = false;
    }
  }
  return out;
}

export function meshBounds(parts: MeshPart[]): { min: [number, number, number]; max: [number, number, number] } {
  const min: [number, number, number] = [Infinity, Infinity, Infinity];
  const max: [number, number, number] = [-Infinity, -Infinity, -Infinity];
  for (const p of parts) {
    for (let i = 0; i < p.positions.length; i += 3) {
      for (let k = 0; k < 3; k++) {
        const v = p.positions[i + k];
        if (v < min[k]) min[k] = v;
        if (v > max[k]) max[k] = v;
      }
    }
  }
  if (!Number.isFinite(min[0])) return { min: [0, 0, 0], max: [0, 0, 0] };
  return { min, max };
}

export function triangleCount(parts: MeshPart[]): number {
  return parts.reduce((s, p) => s + Math.floor(p.positions.length / 9), 0);
}

const safeFile = (s: string) => (s || 'block').replace(/[^A-Za-z0-9 _.-]+/g, '_').replace(/\s+/g, '_').replace(/_+/g, '_').slice(0, 60) || 'block';
export const blockFileBase = safeFile;

const rgbInt = (hex: string) => parseInt((hex || '#808080').replace('#', '').slice(0, 6).padEnd(6, '0'), 16) || 0;

// ---------------------------------------------------------------------------------------------
// DXF (R2000) — a named BLOCK of polyface meshes + one INSERT at the origin
// ---------------------------------------------------------------------------------------------

const dnum = (v: number) => {
  if (!Number.isFinite(v)) return '0.0';
  const r = Math.round(v * 1e6) / 1e6;
  const s = String(r === 0 ? 0 : r);
  return s.includes('.') || s.includes('e') ? s : `${s}.0`;
};

class Buf {
  out: string[] = [];
  s(code: number, v: string) {
    this.out.push(String(code), v);
  }
  f(code: number, v: number) {
    this.out.push(String(code), dnum(v));
  }
  i(code: number, v: number) {
    this.out.push(String(code), String(Math.round(v)));
  }
}

const PFACE_MAX_VERTS = 32000;

export function writeBlockDxf(meta: BlockExportMeta, parts: MeshPart[], units: ExportUnits = 'in'): string {
  const f = UNIT_SCALE[units];
  let next = 0x30;
  const H = () => (next++).toString(16).toUpperCase();
  const hT = { VPORT: H(), LTYPE: H(), LAYER: H(), STYLE: H(), VIEW: H(), UCS: H(), APPID: H(), DIMSTYLE: H(), BLOCK_RECORD: H() };
  const hRoot = H();
  const hGroup = H();
  const hMs = H();
  const hPs = H();
  const hBlk = H();
  const blockName = sanitizeDxfName(meta.name, 'BLOCK').replace(/^\*+/, '') || 'BLOCK';

  // layers, one per material
  const layers = new Map<string, { name: string; color: string }>();
  const layerOf = (p: MeshPart) => {
    const name = sanitizeDxfName(`${p.name || 'body'}`.toUpperCase(), 'BODY');
    if (!layers.has(name)) layers.set(name, { name, color: p.color });
    return name;
  };

  // block body: polyface meshes
  const body = new Buf();
  for (const part of parts) {
    const layer = layerOf(part);
    const mesh = indexMesh(part.positions, f);
    if (!mesh.tris.length) continue;
    const vis = visibleEdges(mesh);
    // split very large meshes (polyface vertex index limit)
    const chunks: number[][] = [];
    let cur: number[] = [];
    let used = new Set<number>();
    for (let t = 0; t < mesh.tris.length / 3; t++) {
      const tv = [mesh.tris[t * 3], mesh.tris[t * 3 + 1], mesh.tris[t * 3 + 2]];
      const add = tv.filter((v) => !used.has(v)).length;
      if (used.size + add > PFACE_MAX_VERTS) {
        chunks.push(cur);
        cur = [];
        used = new Set();
      }
      tv.forEach((v) => used.add(v));
      cur.push(t);
    }
    if (cur.length) chunks.push(cur);

    for (const triIds of chunks) {
      const local = new Map<number, number>();
      const order: number[] = [];
      for (const t of triIds) {
        for (let e = 0; e < 3; e++) {
          const v = mesh.tris[t * 3 + e];
          if (!local.has(v)) {
            local.set(v, order.length + 1);
            order.push(v);
          }
        }
      }
      const hPoly = H();
      const head = (type: string, owner: string, handle: string) => {
        body.s(0, type);
        body.s(5, handle);
        body.s(330, owner);
        body.s(100, 'AcDbEntity');
        body.s(8, layer);
      };
      head('POLYLINE', hBlk, hPoly);
      body.i(62, hexToNearestAci(part.color));
      body.i(420, rgbInt(part.color));
      if (part.opacity < 0.999) body.i(440, 0x02000000 + Math.max(0, Math.min(255, Math.round(part.opacity * 255))));
      body.s(100, 'AcDbPolyFaceMesh');
      body.i(66, 1);
      body.f(10, 0); body.f(20, 0); body.f(30, 0);
      body.i(70, 64);
      body.i(71, order.length);
      body.i(72, triIds.length);
      for (const v of order) {
        head('VERTEX', hPoly, H());
        body.s(100, 'AcDbVertex');
        body.s(100, 'AcDbPolyFaceMeshVertex');
        body.f(10, mesh.verts[v * 3]);
        body.f(20, mesh.verts[v * 3 + 1]);
        body.f(30, mesh.verts[v * 3 + 2]);
        body.i(70, 192);
      }
      for (const t of triIds) {
        head('VERTEX', hPoly, H());
        body.s(100, 'AcDbFaceRecord');
        body.f(10, 0); body.f(20, 0); body.f(30, 0);
        body.i(70, 128);
        for (let e = 0; e < 3; e++) {
          const ix = local.get(mesh.tris[t * 3 + e])!;
          body.i(71 + e, vis[t * 3 + e] ? ix : -ix);
        }
      }
      head('SEQEND', hPoly, H());
    }
  }

  const b = meshBounds(parts);
  const ext = { minX: b.min[0] * f, minY: b.min[1] * f, minZ: b.min[2] * f, maxX: b.max[0] * f, maxY: b.max[1] * f, maxZ: b.max[2] * f };

  // tables
  const T = new Buf();
  const tableHead = (name: keyof typeof hT, count: number) => {
    T.s(0, 'TABLE'); T.s(2, name); T.s(5, hT[name]); T.s(330, '0'); T.s(100, 'AcDbSymbolTable'); T.i(70, count);
  };
  const rec = (type: string, table: keyof typeof hT, sub: string) => {
    T.s(0, type);
    T.s(type === 'DIMSTYLE' ? 105 : 5, H());
    T.s(330, hT[table]);
    T.s(100, 'AcDbSymbolTableRecord');
    T.s(100, sub);
  };
  T.s(0, 'SECTION'); T.s(2, 'TABLES');
  tableHead('VPORT', 1);
  rec('VPORT', 'VPORT', 'AcDbViewportTableRecord');
  T.s(2, '*Active'); T.i(70, 0);
  T.f(10, 0); T.f(20, 0); T.f(11, 1); T.f(21, 1);
  T.f(12, (ext.minX + ext.maxX) / 2); T.f(22, (ext.minY + ext.maxY) / 2);
  T.f(13, 0); T.f(23, 0); T.f(14, 1); T.f(24, 1); T.f(15, 1); T.f(25, 1);
  // look from the front-right-top (SE isometric) so the 3D model is obvious when opened
  T.f(16, 1); T.f(26, -1); T.f(36, 1); T.f(17, (ext.minX + ext.maxX) / 2); T.f(27, (ext.minY + ext.maxY) / 2); T.f(37, (ext.minZ + ext.maxZ) / 2);
  T.f(40, Math.max(1, (Math.max(ext.maxX - ext.minX, ext.maxY - ext.minY, ext.maxZ - ext.minZ)) * 1.8));
  T.f(41, 1.6); T.f(42, 50); T.f(43, 0); T.f(44, 0); T.f(50, 0); T.f(51, 0);
  T.i(71, 0); T.i(72, 1000); T.i(73, 1); T.i(74, 3); T.i(75, 0); T.i(76, 0); T.i(77, 0); T.i(78, 0);
  T.s(0, 'ENDTAB');
  tableHead('LTYPE', 3);
  for (const lt of ['ByBlock', 'ByLayer', 'Continuous']) {
    rec('LTYPE', 'LTYPE', 'AcDbLinetypeTableRecord');
    T.s(2, lt); T.i(70, 0); T.s(3, lt === 'Continuous' ? 'Solid line' : ''); T.i(72, 65); T.i(73, 0); T.f(40, 0);
  }
  T.s(0, 'ENDTAB');
  const layerList = [{ name: '0', color: '#ffffff' }, ...layers.values()];
  tableHead('LAYER', layerList.length);
  for (const l of layerList) {
    rec('LAYER', 'LAYER', 'AcDbLayerTableRecord');
    T.s(2, l.name); T.i(70, 0); T.i(62, l.name === '0' ? 7 : hexToNearestAci(l.color));
    if (l.name !== '0') T.i(420, rgbInt(l.color));
    T.s(6, 'Continuous'); T.i(370, -3);
  }
  T.s(0, 'ENDTAB');
  tableHead('STYLE', 1);
  rec('STYLE', 'STYLE', 'AcDbTextStyleTableRecord');
  T.s(2, 'Standard'); T.i(70, 0); T.f(40, 0); T.f(41, 1); T.f(50, 0); T.i(71, 0); T.f(42, 2.5); T.s(3, 'txt'); T.s(4, '');
  T.s(0, 'ENDTAB');
  tableHead('VIEW', 0); T.s(0, 'ENDTAB');
  tableHead('UCS', 0); T.s(0, 'ENDTAB');
  tableHead('APPID', 1);
  rec('APPID', 'APPID', 'AcDbRegAppTableRecord');
  T.s(2, 'ACAD'); T.i(70, 0);
  T.s(0, 'ENDTAB');
  T.s(0, 'TABLE'); T.s(2, 'DIMSTYLE'); T.s(5, hT.DIMSTYLE); T.s(330, '0'); T.s(100, 'AcDbSymbolTable'); T.i(70, 1); T.s(100, 'AcDbDimStyleTable');
  rec('DIMSTYLE', 'DIMSTYLE', 'AcDbDimStyleTableRecord');
  T.s(2, 'Standard'); T.i(70, 0);
  T.s(0, 'ENDTAB');
  const brs = [
    { name: '*Model_Space', h: hMs },
    { name: '*Paper_Space', h: hPs },
    { name: blockName, h: hBlk },
  ];
  tableHead('BLOCK_RECORD', brs.length);
  for (const br of brs) {
    T.s(0, 'BLOCK_RECORD'); T.s(5, br.h); T.s(330, hT.BLOCK_RECORD); T.s(100, 'AcDbSymbolTableRecord'); T.s(100, 'AcDbBlockTableRecord'); T.s(2, br.name);
    if (br.h === hBlk) T.i(70, units === 'mm' ? 4 : 1); // block insertion units
  }
  T.s(0, 'ENDTAB');
  T.s(0, 'ENDSEC');

  // blocks
  const B = new Buf();
  B.s(0, 'SECTION'); B.s(2, 'BLOCKS');
  for (const br of brs) {
    const ps = br.name === '*Paper_Space';
    B.s(0, 'BLOCK'); B.s(5, H()); B.s(330, br.h); B.s(100, 'AcDbEntity');
    if (ps) B.i(67, 1);
    B.s(8, '0'); B.s(100, 'AcDbBlockBegin'); B.s(2, br.name); B.i(70, 0);
    B.f(10, 0); B.f(20, 0); B.f(30, 0);
    B.s(3, br.name); B.s(1, '');
    if (br.h === hBlk) B.out.push(...body.out);
    B.s(0, 'ENDBLK'); B.s(5, H()); B.s(330, br.h); B.s(100, 'AcDbEntity');
    if (ps) B.i(67, 1);
    B.s(8, '0'); B.s(100, 'AcDbBlockEnd');
  }
  B.s(0, 'ENDSEC');

  // entities: one insert at the origin
  const E = new Buf();
  E.s(0, 'SECTION'); E.s(2, 'ENTITIES');
  E.s(0, 'INSERT'); E.s(5, H()); E.s(330, hMs); E.s(100, 'AcDbEntity'); E.s(8, '0'); E.s(100, 'AcDbBlockReference');
  E.s(2, blockName); E.f(10, 0); E.f(20, 0); E.f(30, 0);
  E.s(0, 'ENDSEC');

  // objects
  const O = new Buf();
  O.s(0, 'SECTION'); O.s(2, 'OBJECTS');
  O.s(0, 'DICTIONARY'); O.s(5, hRoot); O.s(330, '0'); O.s(100, 'AcDbDictionary'); O.i(281, 1); O.s(3, 'ACAD_GROUP'); O.s(350, hGroup);
  O.s(0, 'DICTIONARY'); O.s(5, hGroup); O.s(330, hRoot); O.s(100, 'AcDbDictionary'); O.i(281, 1);
  O.s(0, 'ENDSEC');

  const out = new Buf();
  out.s(0, 'SECTION'); out.s(2, 'HEADER');
  out.s(9, '$ACADVER'); out.s(1, 'AC1015');
  out.s(9, '$DWGCODEPAGE'); out.s(3, 'ANSI_1252');
  out.s(9, '$HANDSEED'); out.s(5, (next + 16).toString(16).toUpperCase());
  out.s(9, '$INSBASE'); out.f(10, 0); out.f(20, 0); out.f(30, 0);
  out.s(9, '$EXTMIN'); out.f(10, ext.minX); out.f(20, ext.minY); out.f(30, ext.minZ);
  out.s(9, '$EXTMAX'); out.f(10, ext.maxX); out.f(20, ext.maxY); out.f(30, ext.maxZ);
  out.s(9, '$INSUNITS'); out.i(70, units === 'mm' ? 4 : 1);
  out.s(9, '$MEASUREMENT'); out.i(70, units === 'mm' ? 1 : 0);
  out.s(9, '$LUNITS'); out.i(70, units === 'mm' ? 2 : 4);
  out.s(9, '$CLAYER'); out.s(8, '0');
  out.s(0, 'ENDSEC');
  out.s(0, 'SECTION'); out.s(2, 'CLASSES'); out.s(0, 'ENDSEC');
  out.out.push(...T.out, ...B.out, ...E.out, ...O.out);
  out.s(0, 'EOF');
  return out.out.join('\n') + '\n';
}

// ---------------------------------------------------------------------------------------------
// OBJ + MTL (Y up, the OBJ convention)
// ---------------------------------------------------------------------------------------------

export function writeBlockObj(meta: BlockExportMeta, parts: MeshPart[], units: ExportUnits = 'in'): { obj: string; mtl: string; mtlName: string } {
  const f = UNIT_SCALE[units];
  const base = safeFile(meta.name);
  const mtlName = `${base}.mtl`;
  const o: string[] = [
    `# ${meta.name} — exported from ARCHIFORMA`,
    `# Units: ${units === 'mm' ? 'millimeters' : 'inches'}. Y is up (OBJ convention); the front of the block faces +Z.`,
    `mtllib ${mtlName}`,
    `o ${base}`,
  ];
  const m: string[] = [`# Materials for ${meta.name}`];
  const seen = new Set<string>();
  let vOffset = 0;
  for (const part of parts) {
    const mesh = indexMesh(part.positions, f);
    if (!mesh.tris.length) continue;
    const matName = safeFile(part.name || 'body');
    if (!seen.has(matName)) {
      seen.add(matName);
      const c = rgbInt(part.color);
      const r = ((c >> 16) & 255) / 255, g = ((c >> 8) & 255) / 255, bl = (c & 255) / 255;
      m.push('', `newmtl ${matName}`, `Kd ${r.toFixed(4)} ${g.toFixed(4)} ${bl.toFixed(4)}`, `Ka 0 0 0`, `Ks 0.05 0.05 0.05`, `Ns 20`, `d ${part.opacity.toFixed(3)}`, `illum 2`);
    }
    o.push(`g ${base}_${matName}`, `usemtl ${matName}`);
    for (let i = 0; i < mesh.verts.length; i += 3) {
      // CAD (X, Y back, Z up) → OBJ (X, Y up, Z front)
      o.push(`v ${dnum(mesh.verts[i])} ${dnum(mesh.verts[i + 2])} ${dnum(-mesh.verts[i + 1])}`);
    }
    for (let t = 0; t < mesh.tris.length; t += 3) {
      o.push(`f ${mesh.tris[t] + 1 + vOffset} ${mesh.tris[t + 1] + 1 + vOffset} ${mesh.tris[t + 2] + 1 + vOffset}`);
    }
    vOffset += mesh.verts.length / 3;
  }
  return { obj: o.join('\n') + '\n', mtl: m.join('\n') + '\n', mtlName };
}

// ---------------------------------------------------------------------------------------------
// STL (binary, Z up)
// ---------------------------------------------------------------------------------------------

export function writeBlockStl(meta: BlockExportMeta, parts: MeshPart[], units: ExportUnits = 'in'): Uint8Array {
  const f = UNIT_SCALE[units];
  const n = triangleCount(parts);
  const buf = new ArrayBuffer(84 + n * 50);
  const dv = new DataView(buf);
  const header = `ARCHIFORMA ${meta.name} (${units})`.slice(0, 79);
  for (let i = 0; i < header.length; i++) dv.setUint8(i, header.charCodeAt(i) & 0x7f);
  dv.setUint32(80, n, true);
  let off = 84;
  for (const part of parts) {
    const p = part.positions;
    for (let i = 0; i + 8 < p.length; i += 9) {
      const ax = p[i] * f, ay = p[i + 1] * f, az = p[i + 2] * f;
      const bx = p[i + 3] * f, by = p[i + 4] * f, bz = p[i + 5] * f;
      const cx = p[i + 6] * f, cy = p[i + 7] * f, cz = p[i + 8] * f;
      const ux = bx - ax, uy = by - ay, uz = bz - az, vx = cx - ax, vy = cy - ay, vz = cz - az;
      let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      const L = Math.hypot(nx, ny, nz) || 1;
      nx /= L; ny /= L; nz /= L;
      for (const v of [nx, ny, nz, ax, ay, az, bx, by, bz, cx, cy, cz]) {
        dv.setFloat32(off, v, true);
        off += 4;
      }
      dv.setUint16(off, 0, true);
      off += 2;
    }
  }
  return new Uint8Array(buf);
}

// ---------------------------------------------------------------------------------------------
// IFC4 — one IfcFurniture (type + occurrence) with tessellated, colored geometry (mm, Z up)
// ---------------------------------------------------------------------------------------------

export function writeBlockIfc(meta: BlockExportMeta, parts: MeshPart[]): string {
  let id = 1;
  const rows: string[] = [];
  const add = (expr: string) => {
    const n = id++;
    rows.push(`#${n}=${expr};`);
    return n;
  };
  const refs = (ids: number[]) => `(${ids.map((i) => `#${i}`).join(',')})`;
  const key = `archiforma-block::${meta.name}::${meta.width}x${meta.depth}x${meta.height}`;
  const guid = (k: string) => makeIfcGuid(`${key}::${k}`);
  const ts = Math.floor(Date.now() / 1000);

  const o3 = add('IFCCARTESIANPOINT((0.,0.,0.))');
  const dz = add('IFCDIRECTION((0.,0.,1.))');
  const dx = add('IFCDIRECTION((1.,0.,0.))');
  const world = add(`IFCAXIS2PLACEMENT3D(#${o3},#${dz},#${dx})`);
  const person = add(`IFCPERSON($,'Designer',${ifcStr('ARCHIFORMA')},$,$,$,$,$)`);
  const org = add(`IFCORGANIZATION($,'ARCHIFORMA',$,$,$)`);
  const po = add(`IFCPERSONANDORGANIZATION(#${person},#${org},$)`);
  const app = add(`IFCAPPLICATION(#${org},'1.0','ARCHIFORMA CAD/BIM','ARCHIFORMA')`);
  const oh = add(`IFCOWNERHISTORY(#${po},#${app},$,.ADDED.,${ts},#${po},#${app},${ts})`);
  const uLen = add('IFCSIUNIT(*,.LENGTHUNIT.,.MILLI.,.METRE.)');
  const uArea = add('IFCSIUNIT(*,.AREAUNIT.,$,.SQUARE_METRE.)');
  const uVol = add('IFCSIUNIT(*,.VOLUMEUNIT.,$,.CUBIC_METRE.)');
  const uAng = add('IFCSIUNIT(*,.PLANEANGLEUNIT.,$,.RADIAN.)');
  const units = add(`IFCUNITASSIGNMENT((#${uLen},#${uArea},#${uVol},#${uAng}))`);
  const ctx = add(`IFCGEOMETRICREPRESENTATIONCONTEXT($,'Model',3,1.E-05,#${world},$)`);
  const bodyCtx = add(`IFCGEOMETRICREPRESENTATIONSUBCONTEXT('Body','Model',*,*,*,*,#${ctx},$,.MODEL_VIEW.,$)`);
  const project = add(`IFCPROJECT('${guid('project')}',#${oh},${ifcStr(meta.name)},$,$,$,$,(#${ctx}),#${units})`);
  const sitePl = add(`IFCLOCALPLACEMENT($,#${world})`);
  const site = add(`IFCSITE('${guid('site')}',#${oh},'Site',$,$,#${sitePl},$,$,.ELEMENT.,$,$,$,$,$)`);
  const bldPl = add(`IFCLOCALPLACEMENT(#${sitePl},#${world})`);
  const bld = add(`IFCBUILDING('${guid('building')}',#${oh},'Building',$,$,#${bldPl},$,$,.ELEMENT.,$,$,$)`);
  const stPl = add(`IFCLOCALPLACEMENT(#${bldPl},#${world})`);
  const storey = add(`IFCBUILDINGSTOREY('${guid('storey')}',#${oh},'Level 1',$,$,#${stPl},$,$,.ELEMENT.,0.)`);
  add(`IFCRELAGGREGATES('${guid('r1')}',#${oh},$,$,#${project},(#${site}))`);
  add(`IFCRELAGGREGATES('${guid('r2')}',#${oh},$,$,#${site},(#${bld}))`);
  add(`IFCRELAGGREGATES('${guid('r3')}',#${oh},$,$,#${bld},(#${storey}))`);

  // geometry: one triangulated face set per material, each with a surface style
  const items: number[] = [];
  for (const part of parts) {
    const mesh = indexMesh(part.positions, 25.4);
    if (!mesh.tris.length) continue;
    const pts: string[] = [];
    for (let i = 0; i < mesh.verts.length; i += 3) pts.push(`(${ifcReal(mesh.verts[i])},${ifcReal(mesh.verts[i + 1])},${ifcReal(mesh.verts[i + 2])})`);
    const tri: string[] = [];
    for (let t = 0; t < mesh.tris.length; t += 3) tri.push(`(${mesh.tris[t] + 1},${mesh.tris[t + 1] + 1},${mesh.tris[t + 2] + 1})`);
    const list = add(`IFCCARTESIANPOINTLIST3D((${pts.join(',')}),$)`);
    const fs = add(`IFCTRIANGULATEDFACESET(#${list},$,.T.,(${tri.join(',')}),$)`);
    const c = rgbInt(part.color);
    const rgb = add(`IFCCOLOURRGB($,${ifcReal(((c >> 16) & 255) / 255)},${ifcReal(((c >> 8) & 255) / 255)},${ifcReal((c & 255) / 255)})`);
    const shading = add(`IFCSURFACESTYLESHADING(#${rgb},${ifcReal(Math.max(0, Math.min(1, 1 - part.opacity)))})`);
    const style = add(`IFCSURFACESTYLE(${ifcStr(part.name || 'body')},.BOTH.,(#${shading}))`);
    add(`IFCSTYLEDITEM(#${fs},(#${style}),$)`);
    items.push(fs);
  }
  const rep = add(`IFCSHAPEREPRESENTATION(#${bodyCtx},'Body','Tessellation',${refs(items)})`);
  const map = add(`IFCREPRESENTATIONMAP(#${world},#${rep})`);

  // type (becomes the Revit family / type) + one occurrence mapping it
  const typeName = ifcStr(meta.name);
  // IfcFurnitureType: …, RepresentationMaps, Tag, ElementType, AssemblyPlace, PredefinedType
  const ftype = add(`IFCFURNITURETYPE('${guid('type')}',#${oh},${typeName},${ifcStr(meta.description || '')},$,$,(#${map}),$,${ifcStr(meta.category || 'Furniture')},.NOTDEFINED.,.USERDEFINED.)`);
  const mapped = add(`IFCMAPPEDITEM(#${map},#${add(`IFCCARTESIANTRANSFORMATIONOPERATOR3D($,$,#${o3},1.,$)`)})`);
  const occRep = add(`IFCSHAPEREPRESENTATION(#${bodyCtx},'Body','MappedRepresentation',(#${mapped}))`);
  const pds = add(`IFCPRODUCTDEFINITIONSHAPE($,$,(#${occRep}))`);
  const elPl = add(`IFCLOCALPLACEMENT(#${stPl},#${world})`);
  const furn = add(`IFCFURNITURE('${guid('occurrence')}',#${oh},${typeName},${ifcStr(meta.description || '')},${ifcStr(meta.category || 'Furniture')},#${elPl},#${pds},$,.NOTDEFINED.)`);
  add(`IFCRELDEFINESBYTYPE('${guid('rtype')}',#${oh},$,$,(#${furn}),#${ftype})`);
  add(`IFCRELCONTAINEDINSPATIALSTRUCTURE('${guid('rcont')}',#${oh},$,$,(#${furn}),#${storey})`);

  // dimensions as a property set
  const pv = (n: string, v: number) => add(`IFCPROPERTYSINGLEVALUE(${ifcStr(n)},$,IFCLENGTHMEASURE(${ifcReal(v * 25.4)}),$)`);
  const props = [pv('Width', meta.width), pv('Depth', meta.depth), pv('Height', meta.height)];
  if (meta.category) props.push(add(`IFCPROPERTYSINGLEVALUE('Category',$,IFCLABEL(${ifcStr(meta.category)}),$)`));
  const pset = add(`IFCPROPERTYSET('${guid('pset')}',#${oh},'ARCHIFORMA_Block',$,${refs(props)})`);
  add(`IFCRELDEFINESBYPROPERTIES('${guid('rpset')}',#${oh},$,$,(#${furn}),#${pset})`);

  const nowIso = new Date().toISOString().slice(0, 19);
  return [
    'ISO-10303-21;',
    'HEADER;',
    "FILE_DESCRIPTION(('ViewDefinition [ReferenceView]'),'2;1');",
    `FILE_NAME(${ifcStr(`${safeFile(meta.name)}.ifc`)},'${nowIso}',('Designer'),('ARCHIFORMA'),'ARCHIFORMA Block Exporter','ARCHIFORMA 1.0','');`,
    "FILE_SCHEMA(('IFC4'));",
    'ENDSEC;',
    'DATA;',
    ...rows,
    'ENDSEC;',
    'END-ISO-10303-21;',
    '',
  ].join('\n');
}

// ---------------------------------------------------------------------------------------------
// ZIP (stored, no compression) — enough for bundling a few export files
// ---------------------------------------------------------------------------------------------

let CRC_TABLE: Uint32Array | null = null;
function crc32(data: Uint8Array): number {
  if (!CRC_TABLE) {
    CRC_TABLE = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      CRC_TABLE[n] = c >>> 0;
    }
  }
  let crc = 0xffffffff;
  for (let i = 0; i < data.length; i++) crc = CRC_TABLE[(crc ^ data[i]) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

export function makeZip(files: Array<{ name: string; data: Uint8Array | string }>): Uint8Array {
  const enc = new TextEncoder();
  const chunks: Uint8Array[] = [];
  const central: Uint8Array[] = [];
  let offset = 0;
  const d = new Date();
  const dosTime = (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2);
  const dosDate = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  for (const f of files) {
    const data = typeof f.data === 'string' ? enc.encode(f.data) : f.data;
    const name = enc.encode(f.name);
    const crc = crc32(data);
    const local = new DataView(new ArrayBuffer(30));
    local.setUint32(0, 0x04034b50, true);
    local.setUint16(4, 20, true);
    local.setUint16(6, 0x0800, true); // UTF-8 names
    local.setUint16(8, 0, true);
    local.setUint16(10, dosTime, true);
    local.setUint16(12, dosDate, true);
    local.setUint32(14, crc, true);
    local.setUint32(18, data.length, true);
    local.setUint32(22, data.length, true);
    local.setUint16(26, name.length, true);
    local.setUint16(28, 0, true);
    chunks.push(new Uint8Array(local.buffer), name, data);
    const cen = new DataView(new ArrayBuffer(46));
    cen.setUint32(0, 0x02014b50, true);
    cen.setUint16(4, 20, true);
    cen.setUint16(6, 20, true);
    cen.setUint16(8, 0x0800, true);
    cen.setUint16(10, 0, true);
    cen.setUint16(12, dosTime, true);
    cen.setUint16(14, dosDate, true);
    cen.setUint32(16, crc, true);
    cen.setUint32(20, data.length, true);
    cen.setUint32(24, data.length, true);
    cen.setUint16(28, name.length, true);
    cen.setUint32(42, offset, true);
    central.push(new Uint8Array(cen.buffer), name);
    offset += 30 + name.length + data.length;
  }
  const cenSize = central.reduce((s, c) => s + c.length, 0);
  const end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true);
  end.setUint16(8, files.length, true);
  end.setUint16(10, files.length, true);
  end.setUint32(12, cenSize, true);
  end.setUint32(16, offset, true);
  const all = [...chunks, ...central, new Uint8Array(end.buffer)];
  const out = new Uint8Array(all.reduce((s, c) => s + c.length, 0));
  let p = 0;
  for (const c of all) {
    out.set(c, p);
    p += c.length;
  }
  return out;
}

/** Plain-text how-to bundled in the ZIP. */
export function exportReadme(meta: BlockExportMeta, units: ExportUnits): string {
  const base = safeFile(meta.name);
  const u = units === 'mm' ? 'millimeters' : 'inches';
  return `${meta.name} — 3D block exported from ARCHIFORMA
Size: ${meta.width.toFixed(2)}" W x ${meta.depth.toFixed(2)}" D x ${meta.height.toFixed(2)}" H. File units: ${u} (IFC is always millimeters).
The insertion point is the block's base point on the floor. The front of the block faces -Y (south) in DXF / STL / IFC.

FILES
  ${base}.dxf      3D DXF (AutoCAD 2000 format): a named block "${meta.name}" made of polyface meshes, one layer per material.
  ${base}.obj/.mtl Mesh with colors (Y up, the OBJ standard).
  ${base}.stl      Mesh without colors (Z up).
  ${base}.ifc      IFC4 furniture type + instance with colors (millimeters, Z up).
  ${base}_2D.dxf   The 2D plan symbol.

AUTOCAD
  Insert as a block:  INSERT > Browse > ${base}.dxf (or open it, then use it with DESIGNCENTER / Tool Palettes).
  Turn the meshes into solids if you need to: MESHSMOOTH, then CONVTOSOLID.

REVIT — make a loadable family
  1. File > New > Family > "Furniture.rft" (or "Generic Model.rft").
  2. Insert > Import CAD > ${base}.dxf. Set Import units to "${units === 'mm' ? 'Millimeter' : 'Inch'}" and Positioning to "Auto - Origin to Origin". Click Open.
  3. Optional: also import ${base}_2D.dxf into the Ref. Level plan view for a clean 2D symbol (set it "Visible in plan only").
  4. Save the family, then Load into Project and place it like any other component.
  Other routes: Insert > Import CAD also accepts the .obj and .stl (Revit 2023+); File > Open > IFC opens ${base}.ifc directly.

SKETCHUP / RHINO / 3DS MAX / BLENDER / TWINMOTION
  Import ${base}.obj (keep the .mtl next to it for colors). If it comes in lying on its side, rotate 90° about X.
`;
}

import { test } from 'node:test';
import assert from 'node:assert/strict';
import type { BlockDefinition } from '../types/model';
import { blockMeshParts } from '../components/block3d';
import { meshBounds } from './blockExport';
import {
  addLegs, addTopSlab, centerShapes, copyShape, duplicateBlock, mergeBlocks, mirrorShape, newCustomBlock,
  parseBlockFile, removeShape, serializeBlocks, setPart3D, shapesExtent, uniqueName,
} from './blockLibrary';

test('a new custom block is a single editable box', () => {
  const b = newCustomBlock();
  assert.equal(b.kind, 'custom');
  assert.equal(b.entities.length, 1);
  const bb = meshBounds(blockMeshParts(b));
  assert.deepEqual(bb.max.map((v) => Math.round(v)), [18, 12, 30]);
});

test('quick top + legs build a table that stands on the floor', () => {
  let b = { ...newCustomBlock('Desk'), entities: [], parts3d: {} } as BlockDefinition;
  b = addTopSlab(b, 1.5).block;
  b = addLegs(b, 2, 1, 1.5).block;
  assert.equal(b.entities.length, 5);
  const parts = blockMeshParts(b);
  const bb = meshBounds(parts);
  assert.equal(Math.round(bb.min[2]), 0);
  assert.equal(Math.round(bb.max[2] * 10) / 10, 30);
  // legs reach exactly the underside of the top
  const legTops = Object.values(b.parts3d!).filter((p) => (p.z ?? 0) === 0).map((p) => p.height);
  assert.deepEqual(legTops, [28.5, 28.5, 28.5, 28.5]);
});

test('copy / mirror / remove shapes keep 3D settings in sync', () => {
  let b = addLegs({ ...newCustomBlock(), entities: [], parts3d: {} }).block;
  const first = b.entities[0];
  const { block, newId } = copyShape(b, first.id, 'x');
  b = block;
  const src = b.entities.find((e) => e.id === first.id)!;
  const cp = b.entities.find((e) => e.id === newId)!;
  assert.ok(src.type === 'rectangle' && cp.type === 'rectangle');
  if (src.type === 'rectangle' && cp.type === 'rectangle') assert.equal(cp.p1.x, -src.p1.x);
  assert.deepEqual(b.parts3d![newId], b.parts3d![first.id]);
  b = removeShape(b, newId);
  assert.equal(b.parts3d![newId], undefined);
  assert.ok(!b.entities.some((e) => e.id === newId));
});

test('arc mirroring flips its angles', () => {
  const m = mirrorShape({ id: 'a', type: 'arc', layer: '0', center: { x: 10, y: 0 }, radius: 5, startAngle: 0, endAngle: 90 }, 'x');
  assert.ok(m.type === 'arc');
  if (m.type === 'arc') {
    assert.equal(m.center.x, -10);
    assert.deepEqual([m.startAngle, m.endAngle], [90, 180]);
  }
});

test('setPart3D merges and clears fields', () => {
  let b = newCustomBlock();
  const id = b.entities[0].id;
  b = setPart3D(b, id, { z: 10, color: '#ff0000' });
  b = setPart3D(b, id, { color: undefined });
  assert.deepEqual(b.parts3d![id], { z: 10 });
});

test('centre + extent', () => {
  const b: BlockDefinition = { ...newCustomBlock(), entities: [{ id: 'r', type: 'rectangle', layer: '0', p1: { x: 0, y: 0 }, p2: { x: 40, y: 20 } }] };
  const c = centerShapes(b);
  const r = c.entities[0];
  assert.ok(r.type === 'rectangle' && r.p1.x === -20 && r.p1.y === -10);
  assert.deepEqual(shapesExtent(c), { width: 40, depth: 20 });
});

test('duplicate gives fresh ids and remaps 3D settings', () => {
  const b = addLegs(newCustomBlock('Bench')).block;
  const d = duplicateBlock(b, [b]);
  assert.notEqual(d.id, b.id);
  assert.equal(d.name, 'Bench copy');
  assert.equal(Object.keys(d.parts3d!).length, Object.keys(b.parts3d!).length);
  for (const k of Object.keys(d.parts3d!)) assert.ok(d.entities.some((e) => e.id === k));
  assert.ok(d.entities.every((e) => !b.entities.some((o) => o.id === e.id)));
});

test('block files round-trip and merge without clobbering', () => {
  const a = addLegs(newCustomBlock('Stool')).block;
  const file = serializeBlocks([a]);
  const parsed = parseBlockFile(file);
  assert.equal(parsed[0].name, 'Stool');
  // importing the same block again is skipped; a different block with the same id is renamed
  const again = mergeBlocks([a], parsed);
  assert.equal(again.added.length, 0);
  assert.equal(again.skipped, 1);
  const changed = mergeBlocks([a], [{ ...parsed[0], height: 18 }]);
  assert.equal(changed.added.length, 1);
  assert.notEqual(changed.added[0].id, a.id);
  assert.equal(changed.added[0].name, 'Stool (2)');
  // a whole project file works too; junk is rejected
  assert.equal(parseBlockFile(JSON.stringify({ projectName: 'x', blocks: [a] })).length, 1);
  assert.throws(() => parseBlockFile('{"blocks":[{"name":"x"}]}'), /No blocks/);
  assert.throws(() => parseBlockFile('nope'), /JSON/);
  assert.equal(uniqueName('Stool', [a, { ...a, name: 'Stool (2)' }]), 'Stool (3)');
});

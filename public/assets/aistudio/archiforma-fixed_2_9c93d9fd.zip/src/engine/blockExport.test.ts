import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as fs from 'node:fs';
import * as path from 'node:path';
import * as zlib from 'node:zlib';
import type { BlockDefinition } from '../types/model';
import { blockMeshParts, partSettings } from '../components/block3d';
import { createBlankProject } from './geometry';
import { indexMesh, makeZip, meshBounds, triangleCount, visibleEdges, writeBlockDxf, writeBlockIfc, writeBlockObj, writeBlockStl, type BlockExportMeta } from './blockExport';

/** 48" × 30" table: 1.5" wood top on four 2"×2" legs, plus a 2D-only circle (a vase symbol). */
export const TABLE: BlockDefinition = {
  id: 'blk-table', name: 'Dining Table 48x30', category: 'Custom', kind: 'custom', width: 48, depth: 30, height: 30, color: '#334155',
  entities: [
    { id: 'top', type: 'rectangle', layer: '0', p1: { x: -24, y: -15 }, p2: { x: 24, y: 15 } },
    { id: 'l1', type: 'rectangle', layer: '0', p1: { x: -23, y: -14 }, p2: { x: -21, y: -12 } },
    { id: 'l2', type: 'rectangle', layer: '0', p1: { x: 21, y: -14 }, p2: { x: 23, y: -12 } },
    { id: 'l3', type: 'rectangle', layer: '0', p1: { x: -23, y: 12 }, p2: { x: -21, y: 14 } },
    { id: 'l4', type: 'rectangle', layer: '0', p1: { x: 21, y: 12 }, p2: { x: 23, y: 14 } },
    { id: 'vase', type: 'circle', layer: '0', center: { x: 0, y: 0 }, radius: 4 },
  ],
  parts3d: {
    top: { z: 28.5, height: 1.5, color: '#8a5a33' },
    l1: { height: 28.5 }, l2: { height: 28.5 }, l3: { height: 28.5 }, l4: { height: 28.5 },
    vase: { hidden: true },
  },
};

const meta = (b: BlockDefinition): BlockExportMeta => ({ name: b.name, category: b.category, width: b.width, depth: b.depth, height: b.height });
const OUT = process.env.BLOCK_EXPORT_OUT;

test('custom block: per-shape height, base and color; hidden shapes stay 2D', () => {
  const parts = blockMeshParts(TABLE);
  assert.equal(parts.length, 2, 'two materials: wood top + body-colored legs');
  const top = parts.find((p) => p.color === '#8a5a33')!;
  const legs = parts.find((p) => p.color === '#334155')!;
  const tb = meshBounds([top]);
  assert.deepEqual(tb.min.map((v) => Math.round(v * 100) / 100), [-24, -15, 28.5]);
  assert.deepEqual(tb.max.map((v) => Math.round(v * 100) / 100), [24, 15, 30]);
  assert.equal(triangleCount([legs]), 4 * 12, 'four boxes, no vase cylinder');
  const all = meshBounds(parts);
  assert.equal(Math.round(all.min[2]), 0);
  // plan +y (front, bottom of the symbol) maps to CAD −Y
  const lb = meshBounds([legs]);
  assert.ok(lb.min[1] < -13 && lb.max[1] > 13);
});

test('partSettings clamps into the block height', () => {
  const s = partSettings({ ...TABLE, parts3d: { top: { z: 40, height: 10 } } }, 'top');
  assert.ok(s.z < 30 && s.z + s.height <= 30.0001);
  assert.deepEqual(partSettings(TABLE, 'missing'), { z: 0, height: 30, color: '#334155', hidden: false });
});

test('closed polylines extrude upward with the right plan orientation', () => {
  const L: BlockDefinition = {
    id: 'blk-l', name: 'L Counter', category: 'Custom', kind: 'custom', width: 96, depth: 72, height: 36, color: '#78716c',
    entities: [{ id: 'p', type: 'polyline', layer: '0', closed: true, points: [{ x: 0, y: 0 }, { x: 96, y: 0 }, { x: 96, y: 24 }, { x: 24, y: 24 }, { x: 24, y: 72 }, { x: 0, y: 72 }] }],
    parts3d: { p: { z: 0, height: 36 } },
  };
  const b = meshBounds(blockMeshParts(L));
  assert.deepEqual(b.min.map((v) => Math.round(v) + 0), [0, -72, 0]);
  assert.deepEqual(b.max.map((v) => Math.round(v) + 0), [96, 0, 36]);
});

test('every starter and library block exports finite geometry', () => {
  const blocks = createBlankProject().blocks ?? [];
  assert.ok(blocks.length > 20);
  for (const b of blocks) {
    const parts = blockMeshParts(b);
    const n = triangleCount(parts);
    assert.ok(n > 0, `${b.name} has triangles`);
    for (const p of parts) assert.ok(p.positions.every(Number.isFinite), `${b.name} finite`);
    const bb = meshBounds(parts);
    assert.ok(bb.max[2] - bb.min[2] > 0.5, `${b.name} has height`);
  }
});

test('coplanar triangle seams are hidden, real edges kept', () => {
  // a unit box: 12 triangles, 36 edge slots, 6 diagonals shared by coplanar pairs (12 slots hidden)
  const parts = blockMeshParts({ ...TABLE, entities: [TABLE.entities[0]], parts3d: {} });
  const m = indexMesh(parts[0].positions);
  const vis = visibleEdges(m);
  assert.equal(vis.filter((v) => !v).length, 12);
});

test('DXF: one named block of polyface meshes, unique handles, inserted once', () => {
  const parts = blockMeshParts(TABLE);
  const dxf = writeBlockDxf(meta(TABLE), parts, 'in');
  const lines = dxf.split('\n');
  const pairs: Array<[string, string]> = [];
  for (let i = 0; i + 1 < lines.length; i += 2) pairs.push([lines[i].trim(), lines[i + 1]]);
  const seedAt = pairs.findIndex(([c, v]) => c === '9' && v === '$HANDSEED') + 1;
  const handles = pairs.filter(([c], i) => (c === '5' || c === '105') && i !== seedAt).map(([, v]) => v);
  assert.equal(new Set(handles).size, handles.length, 'handles unique');
  const seed = parseInt(pairs[seedAt][1], 16);
  assert.ok(handles.every((h) => parseInt(h, 16) < seed), 'HANDSEED above all handles');
  const zero = pairs.filter(([c]) => c === '0').map(([, v]) => v);
  assert.equal(zero.filter((v) => v === 'POLYLINE').length, 2);
  assert.equal(zero.filter((v) => v === 'SEQEND').length, 2);
  assert.equal(zero.filter((v) => v === 'INSERT').length, 1);
  assert.equal(zero.filter((v) => v === 'BLOCK').length, 3);
  const faces = pairs.filter(([c, v]) => c === '100' && v === 'AcDbFaceRecord').length;
  assert.equal(faces, triangleCount(parts));
  assert.ok(pairs.some(([c, v]) => c === '2' && v === 'Dining Table 48x30'));
  assert.ok(pairs.some(([c, v]) => c === '73' && v.startsWith('-')), 'some invisible edges');
  assert.equal(lines[lines.length - 2], 'EOF');
  if (OUT) fs.writeFileSync(path.join(OUT, 'table.dxf'), dxf);
});

test('DXF in millimetres scales coordinates and sets INSUNITS=4', () => {
  const dxf = writeBlockDxf(meta(TABLE), blockMeshParts(TABLE), 'mm');
  assert.match(dxf, /\$INSUNITS\n70\n4\n/);
  assert.match(dxf, /\n30\n762\.0\n/, '30" top = 762 mm');
});

test('OBJ/MTL, STL and IFC are well formed', () => {
  const parts = blockMeshParts(TABLE);
  const n = triangleCount(parts);
  const { obj, mtl, mtlName } = writeBlockObj(meta(TABLE), parts, 'in');
  assert.equal(mtlName, 'Dining_Table_48x30.mtl');
  assert.equal(obj.split('\n').filter((l) => l.startsWith('f ')).length, n);
  assert.equal(mtl.split('\n').filter((l) => l.startsWith('newmtl ')).length, 2);
  const maxIdx = Math.max(...obj.split('\n').filter((l) => l.startsWith('f ')).flatMap((l) => l.slice(2).split(' ').map(Number)));
  assert.equal(maxIdx, obj.split('\n').filter((l) => l.startsWith('v ')).length);

  const stl = writeBlockStl(meta(TABLE), parts, 'mm');
  assert.equal(stl.length, 84 + 50 * n);
  assert.equal(new DataView(stl.buffer).getUint32(80, true), n);

  const ifc = writeBlockIfc(meta(TABLE), parts);
  const defined = new Set([...ifc.matchAll(/^#(\d+)=/gm)].map((m) => m[1]));
  for (const m of ifc.matchAll(/#(\d+)/g)) assert.ok(defined.has(m[1]), `#${m[1]} defined`);
  assert.equal((ifc.match(/IFCTRIANGULATEDFACESET/g) ?? []).length, 2);
  assert.match(ifc, /IFCFURNITURE\('/);
  assert.match(ifc, /IFCFURNITURETYPE\(/);
  if (OUT) {
    fs.writeFileSync(path.join(OUT, 'table.obj'), obj);
    fs.writeFileSync(path.join(OUT, mtlName), mtl);
    fs.writeFileSync(path.join(OUT, 'table.stl'), stl);
    fs.writeFileSync(path.join(OUT, 'table.ifc'), ifc);
  }
});

test('ZIP: stored entries with correct CRCs', () => {
  const files = [
    { name: 'a.txt', data: 'hello' },
    { name: 'b.bin', data: new Uint8Array([0, 1, 2, 255]) },
  ];
  const zip = makeZip(files);
  const dv = new DataView(zip.buffer, zip.byteOffset, zip.byteLength);
  let off = 0;
  for (const f of files) {
    assert.equal(dv.getUint32(off, true), 0x04034b50);
    const crc = dv.getUint32(off + 14, true);
    const size = dv.getUint32(off + 18, true);
    const nameLen = dv.getUint16(off + 26, true);
    const data = zip.slice(off + 30 + nameLen, off + 30 + nameLen + size);
    assert.equal(crc, zlib.crc32(data), `${f.name} crc`);
    off += 30 + nameLen + size;
  }
  assert.equal(dv.getUint32(zip.length - 22, true), 0x06054b50);
  if (OUT) fs.writeFileSync(path.join(OUT, 'test.zip'), zip);
});

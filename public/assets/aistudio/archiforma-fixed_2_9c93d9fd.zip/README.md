# ARCHIFORMA

A simple, friendly 2D/3D architectural CAD and light BIM tool using AutoCAD and Revit commands and shortcuts.

View in AI Studio: https://ai.studio/apps/1773a4c3-f439-4b0f-b46c-54bc18f6da2c

## Design with AI (sketch → plan)

At the bottom of the 2D plan there is a **Design with AI** bar (or type `AI` in the command line).

1. Click **+** to attach a photo or scan of a hand sketch (JPG, PNG, WebP or PDF). You can also drag an image onto the bar or paste one.
2. Optionally type notes ("overall 40 ft wide", "make room 3 an office"), or skip the sketch and just describe the plan you want.
3. Press **Enter**. Gemini reads the sketch and ARCHIFORMA draws real walls, doors, windows, rooms and overall dimensions, which you can edit, view in 3D and export like anything else.
4. **Ctrl+Z** (or the Undo button on the result card) takes it back.

The menu under the bar chooses where the plan goes: a new project, replace everything on the current level, or add beside the current plan.

**API key:** the first time, click the settings icon and paste a free Gemini API key from https://aistudio.google.com/apikey. It is saved only in that browser. Inside Google AI Studio the app uses AI Studio's own key automatically.
Never put your key in a `.env` file for a build you publish: `npm run build:html` always strips it, but `npm run build` does not.

## Custom 3D blocks (and using them in AutoCAD / Revit)

**Library tab → Blank** starts a new block; **BE** on any library card edits it.

- Each rectangle, circle or closed polygon in a custom block becomes a 3D solid with its own **base height, height and color**. Mark a shape **2D only** to keep it as symbol lines.
- **Quick parts:** *Top slab* + *4 legs* make a table in two clicks. **Copy** and **Mirror ↔ / ↕** duplicate shapes (legs, drawers, cushions). **Center** and **Fit size** tidy up the insertion point and size.
- Live **3D preview** (drag to orbit), **New / Duplicate / Delete** block, and a description field that goes into IFC.
- **Share** saves your custom blocks to a `.archiblocks.json` file; **Import** brings them into another project (it never overwrites; renamed copies are added).

**Download 3D** (in the Block Editor, or the download icon on any library card) exports one block as:

| File | Use it in |
|---|---|
| 3D DXF (AutoCAD 2000) | AutoCAD `INSERT`; Revit *Insert ▸ Import CAD* (also inside the Family Editor) |
| IFC4 furniture type | Revit *File ▸ Open ▸ IFC*, ArchiCAD, BIM viewers |
| OBJ + MTL | Revit 2023+, SketchUp, Blender, 3ds Max, Rhino, Twinmotion |
| STL | Revit, 3D printing |
| 2D plan symbol DXF | AutoCAD 2D, Revit family plan views |

**Download everything (.zip)** bundles them all with a `HOW-TO-USE.txt`. Revit family files (`.rfa`) are a closed format no app outside Revit can write, so the dialog walks you through making the family in Revit: *New Family ▸ Furniture.rft ▸ Import CAD ▸ the .dxf ▸ Save ▸ Load into Project*.

## Run locally

Prerequisite: Node.js 20 or newer.

```bash
npm install
npm run dev        # http://localhost:3000
```

Other scripts: `npm run build` (production build into `dist/`), `npm run preview` (serve the build), `npm test` (engine tests), `npm run lint` (type check).

## Publish on GitHub Pages

This is a Vite + React + TypeScript app, so it has to be **built** before a browser can run it.
If GitHub Pages serves the raw repository files, `index.html` tries to load `src/main.tsx`
directly, the browser can't execute it, and you get a **blank white page**.

The included workflow (`.github/workflows/deploy.yml`) builds the app and publishes the result:

1. Push this project to GitHub (branch `main` or `master`).
2. In the repo, open **Settings → Pages**.
3. Under **Build and deployment → Source**, choose **GitHub Actions** (not "Deploy from a branch").
4. Open the **Actions** tab and wait for "Deploy to GitHub Pages" to go green
   (or click **Run workflow** to start it by hand).
5. The site appears at `https://<your-username>.github.io/<repo-name>/`.

## Simplest option: plain HTML (no build on GitHub)

`docs/index.html` is the whole app compiled into a single HTML file, with no TypeScript left in it.

1. Upload the project (including the `docs` folder) to GitHub.
2. Open **Settings → Pages**. Set **Source** to **Deploy from a branch**, then pick branch `main` and folder **/docs**. Save.
3. After a minute the site is live at `https://<your-username>.github.io/<repo-name>/`.

You can also just double-click `docs/index.html` to run the app offline.
After changing the source code, run `npm run build:html` to regenerate `docs/`.

## Other hosts

Vercel, Netlify and Cloudflare Pages all work with: build command `npm run build`, output directory `dist`.

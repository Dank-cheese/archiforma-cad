# ARCHIFORMA

A simple, friendly 2D/3D architectural CAD and light BIM tool using AutoCAD and Revit commands and shortcuts.

View in AI Studio: https://ai.studio/apps/1773a4c3-f439-4b0f-b46c-54bc18f6da2c

## Design with AI (sketch → plan)

At the bottom of the 2D plan there is a **Design with AI** bar (or type `AI` in the command line).

1. Click **+** to attach a photo or scan of a hand sketch (JPG, PNG, WebP or PDF). You can also drag an image onto the bar or paste one.
2. Optionally type notes ("overall 40 ft wide", "make room 3 an office"), or skip the sketch and just describe the plan you want.
3. Press **Enter**. Gemini reads the sketch and ARCHIFORMA draws real walls, doors, windows, rooms and overall dimensions, which you can edit, view in 3D and export like anything else.
4. **Ctrl+Z** (or the Undo button on the result card) takes it back.

The menu under the bar chooses where the plan goes: a new project, replace everything on the current level, or add beside the current plan.

**API key:** the first time, click the settings icon and paste a free Gemini API key from https://aistudio.google.com/apikey. It is saved only in that browser. Inside Google AI Studio the app uses AI Studio's own key automatically.
Never put your key in a `.env` file for a build you publish: `npm run build:html` always strips it, but `npm run build` does not.

## Custom blocks

**Library tab → Blank** starts a new block; **BE** on any library card edits it.

- Move and resize shapes by typing sizes; **Copy** and **Mirror ↔ / ↕** duplicate them. **Center** and **Fit size** tidy up the insertion point and size.
- **New / Duplicate / Delete** blocks right in the Block Editor (Delete also removes placed copies; Ctrl+Z brings them back).
- **Share** saves your custom blocks to a `.archiblocks.json` file; **Import** brings them into another project (it never overwrites; renamed copies are added).

## Run locally

Prerequisite: Node.js 20 or newer.

```bash
npm install
npm run dev        # http://localhost:3000
```

Other scripts: `npm run build` (production build into `dist/`), `npm run build:html` (the whole app as one `docs/index.html`), `npm run preview` (serve the build), `npm test` (engine tests), `npm run lint` (type check).

## Publish on GitHub Pages

This is a Vite + React + TypeScript app, so it has to be **built** before a browser can run it.
If GitHub Pages serves the raw repository files you get a **blank white page**.
The two GitHub-only helpers are kept out of the AI Studio project (AI Studio does not need them) and are separate downloads:

**Option A — build automatically (recommended):** in your GitHub repo, add the file `.github/workflows/deploy.yml`
(Add file ▸ Create new file, paste the provided `deploy.yml`). Then **Settings → Pages → Source: GitHub Actions**.
Every push builds the app and publishes it to `https://<your-username>.github.io/<repo-name>/`.

**Option B — no build:** upload the provided `archiforma.html` to the repo as `docs/index.html`, then
**Settings → Pages → Deploy from a branch → main → /docs**. Regenerate it after changes with `npm run build:html`.

## Other hosts

Vercel, Netlify and Cloudflare Pages all work with: build command `npm run build`, output directory `dist`.
